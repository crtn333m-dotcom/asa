package com.example.data.repository

import com.example.data.local.FamilyDao
import com.example.data.model.FamilyMember
import kotlinx.coroutines.flow.Flow

class FamilyRepository(private val familyDao: FamilyDao) {
    val allMembers: Flow<List<FamilyMember>> = familyDao.getAllMembers()

    suspend fun getMemberById(id: Int): FamilyMember? {
        return familyDao.getMemberById(id)
    }

    suspend fun insert(member: FamilyMember): Long {
        return familyDao.insertMember(member)
    }

    suspend fun insertAll(members: List<FamilyMember>) {
        familyDao.insertMembers(members)
    }

    suspend fun update(member: FamilyMember) {
        familyDao.updateMember(member)
    }

    suspend fun delete(member: FamilyMember) {
        familyDao.deleteMember(member)
    }

    suspend fun clearAll() {
        familyDao.clearAll()
    }
}
