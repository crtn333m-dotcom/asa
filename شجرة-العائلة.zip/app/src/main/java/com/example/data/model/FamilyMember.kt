package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "family_members")
data class FamilyMember(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val relation: String, // Arabic Relationship: الجد, الجدة, الأب, الأم, الأخ, الأخت, الابن, الابنة, أنا, إلخ
    val gender: String,   // "Male", "Female"
    val generation: Int,  // 0: Grandparents, 1: Parents, 2: Self/Siblings, 3: Children
    val relativeX: Float, // Relative position on screen (0.0f to 1.0f)
    val relativeY: Float, // Relative position on screen (0.0f to 1.0f)
    val parentId: Int? = null, // Links to parental ancestor for connection lines
    val notes: String = ""
)
