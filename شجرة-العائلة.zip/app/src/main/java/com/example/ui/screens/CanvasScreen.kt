package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.widgets.TrunkWidget
import com.example.ui.widgets.CustomTrunkWidget
import com.example.ui.widgets.TrunkAdjustmentPanel
import com.example.ui.widgets.BranchWidget
import com.example.ui.widgets.CustomBranchWidget
import com.example.ui.widgets.BranchAdjustmentPanel
import com.example.ui.widgets.LeafWidget
import com.example.ui.widgets.LeafAdjustmentPanel
import com.example.ui.widgets.drawTrunkVector
import com.example.ui.widgets.drawBranchVector
import com.example.ui.theme.*

enum class ElementType {
    TRUNK, BRANCH, LEAF
}

data class CanvasElement(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: ElementType,
    val x: Float, // relative coordinates (0..1)
    val y: Float, // relative coordinates (0..1)
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val length: Float = 1.0f,
    val thickness: Float = 1.0f,
    val tilt: Float = 0f,
    val tipTaper: Float = 1.0f,
    val deform: Float = 0f,
    val woodColorPreset: Int = 0,
    val effectsPreset: Int = 0,
    val isLocked: Boolean = false,
    val isVisible: Boolean = true,
    val names: List<String> = emptyList(),
    
    // NEW properties for branch support:
    val branchName: String = "",
    val parentId: String? = null,
    val branchShapePreset: Int = 0, // 0: Straight, 1: Slightly curved, 2: Heavily curved, 3: Wavy, 4: Twisted, 5: Old branch
    val customWoodColor: Long? = null, // for color picker selection
    val roughness: Float = 0f,
    val smoothness: Float = 0f,
    val cracks: Float = 0f,
    val woodKnots: Int = 0,
    val innerShadow: Boolean = false,
    val outerShadow: Boolean = false,
    val is3d: Boolean = false,
    val shine: Boolean = false,
    val opacity: Float = 1.0f,
    
    // Connection circle properties:
    val connDirectionOffset: Float = 0f,
    val connFlipH: Boolean = false,
    val connFlipV: Boolean = false,
    val connInvertDir: Boolean = false,
    val connCircleSize: Float = 14f,
    val connCircleColor: Long = 0xFFFFF59D,
    val connCircleVisible: Boolean = true,

    // NEW properties for leaf support:
    val leafName: String = "",
    val leafShapePreset: Int = 0, // 0: Natural, 1: Oval, 2: Long, 3: Wide, 4: Pointed, 5: Round, 6: Heart, 7: Toothed
    val leafColorPreset: Int = 0, // 0: Light Green, 1: Natural Green, 2: Dark Green, 3: Yellow, 4: Orange, 5: Autumn Red, 6: Brown
    val customLeafColor: Long? = null,
    val leafVeinClarity: Float = 0.5f,
    val leafEdgeSmoothing: Float = 0.0f,
    val leafShadow: Boolean = false,
    val leafShine: Boolean = false,
    val leaf3d: Boolean = false,
    val leafOpacity: Float = 1.0f
)

@Composable
fun CanvasScreen(
    elements: List<CanvasElement>,
    activeElementId: String?,
    onActiveElementChange: (String?) -> Unit,
    isPanelOpen: Boolean,
    onPanelOpenChange: (Boolean) -> Unit,
    onAddElement: (ElementType, Float, Float) -> Unit,
    onUpdateElement: (CanvasElement) -> Unit,
    onDeleteElement: (String) -> Unit,
    onClearCanvas: () -> Unit,
    onBack: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onCopySettings: (CanvasElement) -> Unit,
    onPasteSettings: (String) -> Unit,
    hasCopiedSettings: Boolean,
    onAddChildElement: (String, ElementType) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTool by remember { mutableStateOf<ElementType?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(TealDeep, TealMedium, TealDeep)
                )
            )
    ) {
        // Grid background for canvas feel
        CanvasGrid()

        // MAIN CANVAS AREA
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(elements, selectedTool) {
                    detectTapGestures(
                        onTap = { offset ->
                            val canvasWidth = size.width.toFloat()
                            val canvasHeight = size.height.toFloat()
                            val boxSizePx = 100.dp.toPx()

                            val localResolvedCenters = mutableMapOf<String, Offset>()
                            elements.forEach { el ->
                                getResolvedCenter(el, elements, canvasWidth, canvasHeight, boxSizePx, localResolvedCenters)
                            }

                            val priorityMap = mapOf(
                                ElementType.LEAF to 1,
                                ElementType.BRANCH to 2,
                                ElementType.TRUNK to 3
                            )

                            val containingElements = elements.filter { el ->
                                val center = localResolvedCenters[el.id] ?: return@filter false
                                val halfSize = (boxSizePx / 2) * el.scale
                                val left = center.x - halfSize
                                val right = center.x + halfSize
                                val top = center.y - halfSize
                                val bottom = center.y + halfSize
                                offset.x >= left && offset.x <= right && offset.y >= top && offset.y <= bottom
                            }

                            val selectedElement = containingElements.sortedWith(
                                compareBy<CanvasElement> { priorityMap[it.type] ?: 99 }
                                .thenBy { it.scale }
                            ).firstOrNull()

                            if (selectedElement != null) {
                                // Tap: selects element only, panel is closed
                                onActiveElementChange(if (activeElementId == selectedElement.id) null else selectedElement.id)
                                onPanelOpenChange(false)
                            } else {
                                selectedTool?.let { tool ->
                                    val relX = offset.x / canvasWidth
                                    val relY = offset.y / canvasHeight
                                    onAddElement(tool, relX, relY)
                                    selectedTool = null
                                    onActiveElementChange(null)
                                    onPanelOpenChange(false)
                                } ?: run {
                                    onActiveElementChange(null)
                                    onPanelOpenChange(false)
                                }
                            }
                        },
                        onLongPress = { offset ->
                            val canvasWidth = size.width.toFloat()
                            val canvasHeight = size.height.toFloat()
                            val boxSizePx = 100.dp.toPx()

                            val localResolvedCenters = mutableMapOf<String, Offset>()
                            elements.forEach { el ->
                                getResolvedCenter(el, elements, canvasWidth, canvasHeight, boxSizePx, localResolvedCenters)
                            }

                            val priorityMap = mapOf(
                                ElementType.LEAF to 1,
                                ElementType.BRANCH to 2,
                                ElementType.TRUNK to 3
                            )

                            val containingElements = elements.filter { el ->
                                val center = localResolvedCenters[el.id] ?: return@filter false
                                val halfSize = (boxSizePx / 2) * el.scale
                                val left = center.x - halfSize
                                val right = center.x + halfSize
                                val top = center.y - halfSize
                                val bottom = center.y + halfSize
                                offset.x >= left && offset.x <= right && offset.y >= top && offset.y <= bottom
                            }

                            val selectedElement = containingElements.sortedWith(
                                compareBy<CanvasElement> { priorityMap[it.type] ?: 99 }
                                .thenBy { it.scale }
                            ).firstOrNull()

                            if (selectedElement != null) {
                                // Long press selects AND opens edit menu
                                onActiveElementChange(selectedElement.id)
                                onPanelOpenChange(true)
                                selectedTool = null
                            }
                        }
                    )
                }
        ) {
            // Draw all placed elements on canvas
            val resolvedCenters = remember(elements) { mutableMapOf<String, Offset>() }
            elements.forEach { element ->
                val scaleAnim by animateFloatAsState(
                    targetValue = if (activeElementId == element.id) 1.15f else 1.0f,
                    label = "ActiveScale"
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val boxSizePx = 100.dp.toPx()
                            val center = getResolvedCenter(element, elements, size.width, size.height, boxSizePx, resolvedCenters)
                            translationX = center.x - (boxSizePx / 2)
                            translationY = center.y - (boxSizePx / 2)
                            scaleX = element.scale * scaleAnim
                            scaleY = element.scale * scaleAnim
                            rotationZ = element.rotation
                            alpha = if (element.isVisible) 1.0f else 0.22f
                        }
                        .size(100.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .then(
                                if (activeElementId == element.id) {
                                    Modifier.border(1.5.dp, GoldLight, RoundedCornerShape(12.dp))
                                } else Modifier
                            )
                    ) {
                        when (element.type) {
                            ElementType.TRUNK -> CustomTrunkWidget(element = element, modifier = Modifier.fillMaxSize())
                            ElementType.BRANCH -> CustomBranchWidget(
                                element = element,
                                isSelected = activeElementId == element.id,
                                modifier = Modifier.fillMaxSize()
                            )
                            ElementType.LEAF -> LeafWidget(
                                element = element,
                                isSelected = activeElementId == element.id,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }

        // GLASSMORPHIC FIXED TOP BAR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
                .align(Alignment.TopCenter)
        ) {
            // Background glass card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = TealDeep.copy(alpha = 0.7f)
                ),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.25f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back button
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .background(TealMedium.copy(alpha = 0.5f), CircleShape)
                            .size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "رجوع",
                            tint = GoldLight
                        )
                    }

                    // Three Elements selector
                    val hasTrunk = elements.any { it.type == ElementType.TRUNK }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ToolCard(
                            title = "جذع",
                            icon = { TrunkWidget(modifier = Modifier.fillMaxSize()) },
                            isSelected = selectedTool == ElementType.TRUNK,
                            onClick = {
                                if (!hasTrunk) {
                                    selectedTool = if (selectedTool == ElementType.TRUNK) null else ElementType.TRUNK
                                }
                            },
                            testTag = "tool_trunk",
                            isEnabled = !hasTrunk
                        )

                        ToolCard(
                            title = "فرع",
                            icon = { BranchWidget(modifier = Modifier.fillMaxSize()) },
                            isSelected = selectedTool == ElementType.BRANCH,
                            onClick = {
                                selectedTool = if (selectedTool == ElementType.BRANCH) null else ElementType.BRANCH
                            },
                            testTag = "tool_branch"
                        )

                        ToolCard(
                            title = "ورقة",
                            icon = { LeafWidget(modifier = Modifier.fillMaxSize()) },
                            isSelected = selectedTool == ElementType.LEAF,
                            onClick = {
                                selectedTool = if (selectedTool == ElementType.LEAF) null else ElementType.LEAF
                            },
                            testTag = "tool_leaf"
                        )
                    }
                }
            }
        }

        // TOOLBAR AND EDITING CONTROLS (BOTTOM HUD)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp)
                .align(Alignment.BottomCenter),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Helper guide text
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = TealDeep.copy(alpha = 0.85f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .shadow(4.dp)
            ) {
                Text(
                    text = when {
                        selectedTool != null -> "اضغط في أي مكان على اللوحة لوضع الـ ${when(selectedTool) {
                            ElementType.TRUNK -> "جذع"
                            ElementType.BRANCH -> "فرع"
                            ElementType.LEAF -> "ورقة"
                            null -> ""
                        }}"
                        activeElementId != null -> "تم التحديد: استخدم أدوات التحكم بالأسفل للتعديل"
                        else -> "اختر أداة من الشريط العلوي، ثم اضغط على الشاشة للرسم"
                    },
                    color = if (selectedTool != null) GoldLight else Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    textAlign = TextAlign.Center
                )
            }

            // Quick Actions bottom menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Clear Canvas button
                Button(
                    onClick = onClearCanvas,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B2635)),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "مسح الكل", tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مسح الشاشة", color = Color.White, fontWeight = FontWeight.Bold)
                }

                // Active item control buttons
                AnimatedVisibility(
                    visible = activeElementId != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    val activeEl = elements.find { it.id == activeElementId }
                    if (activeEl != null) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(TealDeep.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                                .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                .padding(6.dp)
                        ) {
                            // Scale up
                            IconButton(
                                onClick = {
                                    onUpdateElement(activeEl.copy(scale = (activeEl.scale + 0.15f).coerceIn(0.4f, 3.0f)))
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(TealMedium, CircleShape)
                            ) {
                                Text("+", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
                            }

                            // Scale down
                            IconButton(
                                onClick = {
                                    onUpdateElement(activeEl.copy(scale = (activeEl.scale - 0.15f).coerceIn(0.4f, 3.0f)))
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(TealMedium, CircleShape)
                            ) {
                                Text("-", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center)
                            }

                            // Rotate
                            IconButton(
                                onClick = {
                                    onUpdateElement(activeEl.copy(rotation = (activeEl.rotation + 15f) % 360f))
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(TealMedium, CircleShape)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "تدوير", tint = GoldLight)
                            }

                            // Delete selected
                            IconButton(
                                onClick = {
                                    onDeleteElement(activeEl.id)
                                    onActiveElementChange(null)
                                    onPanelOpenChange(false)
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0xFF8B2635).copy(alpha = 0.2f), CircleShape)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف العنصر", tint = Color.Red)
                            }
                        }
                    }
                }
            }
        }

        // 5. TRUNK ADJUSTMENT PANEL OVERLAY
        val activeEl = elements.find { it.id == activeElementId }
        AnimatedVisibility(
            visible = isPanelOpen && activeEl != null && activeEl.type == ElementType.TRUNK,
            enter = androidx.compose.animation.slideInHorizontally(initialOffsetX = { it }),
            exit = androidx.compose.animation.slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(vertical = 16.dp, horizontal = 12.dp)
        ) {
            if (activeEl != null) {
                TrunkAdjustmentPanel(
                    element = activeEl,
                    onUpdateElement = onUpdateElement,
                    onDeleteElement = {
                        onDeleteElement(activeEl.id)
                        onActiveElementChange(null)
                        onPanelOpenChange(false)
                    },
                    onClose = { onPanelOpenChange(false) },
                    onUndo = onUndo,
                    onRedo = onRedo,
                    canUndo = canUndo,
                    canRedo = canRedo,
                    onCopySettings = onCopySettings,
                    onPasteSettings = onPasteSettings,
                    hasCopiedSettings = hasCopiedSettings,
                    onAddChildBranch = {
                        onAddChildElement(activeEl.id, ElementType.BRANCH)
                    }
                )
            }
        }

        // 6. BRANCH ADJUSTMENT PANEL OVERLAY
        AnimatedVisibility(
            visible = isPanelOpen && activeEl != null && activeEl.type == ElementType.BRANCH,
            enter = androidx.compose.animation.slideInHorizontally(initialOffsetX = { it }),
            exit = androidx.compose.animation.slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(vertical = 16.dp, horizontal = 12.dp)
        ) {
            if (activeEl != null) {
                BranchAdjustmentPanel(
                    element = activeEl,
                    onUpdateElement = onUpdateElement,
                    onDeleteElement = {
                        onDeleteElement(activeEl.id)
                        onActiveElementChange(null)
                        onPanelOpenChange(false)
                    },
                    onClose = { onPanelOpenChange(false) },
                    onAddChildBranch = {
                        onAddChildElement(activeEl.id, ElementType.BRANCH)
                    },
                    onAddChildLeaf = {
                        onAddChildElement(activeEl.id, ElementType.LEAF)
                    },
                    onUndo = onUndo,
                    onRedo = onRedo,
                    canUndo = canUndo,
                    canRedo = canRedo,
                    onCopySettings = onCopySettings,
                    onPasteSettings = onPasteSettings,
                    hasCopiedSettings = hasCopiedSettings
                )
            }
        }

        // 7. LEAF ADJUSTMENT PANEL OVERLAY
        AnimatedVisibility(
            visible = isPanelOpen && activeEl != null && activeEl.type == ElementType.LEAF,
            enter = androidx.compose.animation.slideInHorizontally(initialOffsetX = { it }),
            exit = androidx.compose.animation.slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(vertical = 16.dp, horizontal = 12.dp)
        ) {
            if (activeEl != null) {
                LeafAdjustmentPanel(
                    element = activeEl,
                    onUpdateElement = onUpdateElement,
                    onDeleteElement = {
                        onDeleteElement(activeEl.id)
                        onActiveElementChange(null)
                        onPanelOpenChange(false)
                    },
                    onClose = { onPanelOpenChange(false) },
                    onUndo = onUndo,
                    onRedo = onRedo,
                    canUndo = canUndo,
                    canRedo = canRedo,
                    onCopySettings = onCopySettings,
                    onPasteSettings = onPasteSettings,
                    hasCopiedSettings = hasCopiedSettings
                )
            }
        }
    }
}

@Composable
fun ToolCard(
    title: String,
    icon: @Composable () -> Unit,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
    isEnabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && isEnabled) 0.90f else if (isSelected) 1.08f else 1.0f,
        label = "ToolScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .width(64.dp)
            .then(
                if (isEnabled) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            )
            .testTag(testTag)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (isEnabled) 1.0f else 0.35f
            }
    ) {
        // Upper card drawing
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isSelected) GoldPrimary else TealMedium.copy(alpha = 0.6f)
            ),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = if (isSelected) GoldLight else GoldPrimary.copy(alpha = 0.2f)
            ),
            modifier = Modifier
                .size(48.dp)
                .shadow(
                    elevation = if (isSelected) 6.dp else 2.dp,
                    shape = RoundedCornerShape(14.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                icon()
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = title,
            color = if (isSelected) GoldLight else Color.White.copy(alpha = 0.8f),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun CanvasGrid() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val stepX = 40.dp.toPx()
        val stepY = 40.dp.toPx()
        val width = size.width
        val height = size.height

        for (x in 0 until (width / stepX).toInt()) {
            drawLine(
                color = Color.White.copy(alpha = 0.03f),
                start = Offset(x * stepX, 0f),
                end = Offset(x * stepX, height),
                strokeWidth = 1.dp.toPx()
            )
        }

        for (y in 0 until (height / stepY).toInt()) {
            drawLine(
                color = Color.White.copy(alpha = 0.03f),
                start = Offset(0f, y * stepY),
                end = Offset(width, y * stepY),
                strokeWidth = 1.dp.toPx()
            )
        }
    }
}

fun getResolvedCenter(
    element: CanvasElement,
    allElements: List<CanvasElement>,
    canvasWidth: Float,
    canvasHeight: Float,
    boxSizePx: Float,
    resolvedCenters: MutableMap<String, Offset>
): Offset {
    resolvedCenters[element.id]?.let { return it }
    
    if (element.parentId == null) {
        val center = Offset(element.x * canvasWidth, element.y * canvasHeight)
        resolvedCenters[element.id] = center
        return center
    }
    
    val parent = allElements.find { it.id == element.parentId }
    if (parent == null) {
        val center = Offset(element.x * canvasWidth, element.y * canvasHeight)
        resolvedCenters[element.id] = center
        return center
    }
    
    val parentCenter = getResolvedCenter(parent, allElements, canvasWidth, canvasHeight, boxSizePx, resolvedCenters)
    
    val parentTip = if (parent.type == ElementType.TRUNK) {
        getTrunkTipPixelWithCenter(parent, parentCenter, boxSizePx)
    } else {
        getElementTipPixelWithCenter(parent, parentCenter, boxSizePx)
    }
    
    val childLocalBaseX = 0.15f * boxSizePx
    val childLocalBaseY = 0.85f * boxSizePx
    
    val rx = childLocalBaseX - (boxSizePx / 2)
    val ry = childLocalBaseY - (boxSizePx / 2)
    
    val rad = Math.toRadians(element.rotation.toDouble()).toFloat()
    val cosVal = kotlin.math.cos(rad)
    val sinVal = kotlin.math.sin(rad)
    
    val rotatedX = rx * cosVal - ry * sinVal
    val rotatedY = rx * sinVal + ry * cosVal
    
    val scaledX = rotatedX * element.scale
    val scaledY = rotatedY * element.scale
    
    val center = parentTip - Offset(scaledX, scaledY)
    resolvedCenters[element.id] = center
    return center
}

fun getTrunkTipPixelWithCenter(
    element: CanvasElement,
    center: Offset,
    boxSizePx: Float
): Offset {
    val len = element.length.coerceIn(0.4f, 2.5f)
    val tiltOffset = element.tilt.coerceIn(-60f, 60f) * 2f
    
    val localTipX = (boxSizePx * 0.5f) + tiltOffset
    val localTipY = boxSizePx - (boxSizePx - boxSizePx * 0.42f) * len
    
    val rx = localTipX - (boxSizePx / 2)
    val ry = localTipY - (boxSizePx / 2)
    
    val rad = Math.toRadians(element.rotation.toDouble()).toFloat()
    val cosVal = kotlin.math.cos(rad)
    val sinVal = kotlin.math.sin(rad)
    
    val rotatedX = rx * cosVal - ry * sinVal
    val rotatedY = rx * sinVal + ry * cosVal
    
    val scaledX = rotatedX * element.scale
    val scaledY = rotatedY * element.scale
    
    return center + Offset(scaledX, scaledY)
}

fun getElementTipPixelWithCenter(
    element: CanvasElement,
    center: Offset,
    boxSizePx: Float
): Offset {
    val len = element.length.coerceIn(0.4f, 2.5f)
    val tiltOffset = element.tilt.coerceIn(-45f, 45f) * (boxSizePx / 100f)
    
    var localTipX = 0.85f * boxSizePx + tiltOffset
    var localTipY = (0.85f * boxSizePx) - ((0.85f * boxSizePx) - 0.15f * boxSizePx) * len
    
    when (element.branchShapePreset) {
        1 -> { localTipX -= 5f }
        2 -> { localTipX -= 15f }
        3 -> { localTipX += kotlin.math.sin(len * Math.PI.toFloat()) * 8f }
        4 -> { localTipX -= 10f }
        5 -> { localTipX += 5f }
    }
    
    if (element.connInvertDir) {
        val tempX = localTipX
        val tempY = localTipY
        val baseX = 0.15f * boxSizePx
        val baseY = 0.85f * boxSizePx
        localTipX = baseX - (tempX - baseX)
        localTipY = baseY - (tempY - baseY)
    }

    if (element.connFlipH) {
        localTipX = boxSizePx - localTipX
    }
    if (element.connFlipV) {
        localTipY = boxSizePx - localTipY
    }

    val rx = localTipX - (boxSizePx / 2)
    val ry = localTipY - (boxSizePx / 2)
    
    // Apply connection point direction offset
    val radOffset = Math.toRadians(element.connDirectionOffset.toDouble()).toFloat()
    val cosOffset = kotlin.math.cos(radOffset)
    val sinOffset = kotlin.math.sin(radOffset)
    
    val shiftedX = rx * cosOffset - ry * sinOffset
    val shiftedY = rx * sinOffset + ry * cosOffset
    
    val rad = Math.toRadians(element.rotation.toDouble()).toFloat()
    val cosVal = kotlin.math.cos(rad)
    val sinVal = kotlin.math.sin(rad)
    
    val rotatedX = shiftedX * cosVal - shiftedY * sinVal
    val rotatedY = shiftedX * sinVal + shiftedY * cosVal
    
    val scaledX = rotatedX * element.scale
    val scaledY = rotatedY * element.scale
    
    return center + Offset(scaledX, scaledY)
}
