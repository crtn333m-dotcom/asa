package com.example.ui.widgets

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.example.ui.screens.CanvasElement
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BranchAdjustmentPanel(
    element: CanvasElement,
    onUpdateElement: (CanvasElement) -> Unit,
    onDeleteElement: () -> Unit,
    onClose: () -> Unit,
    onAddChildBranch: () -> Unit,
    onAddChildLeaf: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onCopySettings: (CanvasElement) -> Unit,
    onPasteSettings: (String) -> Unit,
    hasCopiedSettings: Boolean,
    modifier: Modifier = Modifier
) {
    var isEditingBySlider by remember { mutableStateOf(false) }
    var branchNameText by remember { mutableStateOf(element.branchName) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showColorPicker by remember { mutableStateOf(false) }

    val panelAlpha by animateFloatAsState(
        targetValue = if (isEditingBySlider) 0.60f else 1.0f,
        label = "PanelOpacityAnimation"
    )

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف الفرع", color = GoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذا الفرع مع جميع الفروع التابعة له؟ لا يمكن التراجع عن هذا الإجراء.", color = Color.White, fontSize = 14.sp) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteElement()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                ) {
                    Text("نعم، احذف الكل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء", color = Color.White)
                }
            },
            containerColor = TealDeep,
            tonalElevation = 6.dp
        )
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = TealDeep.copy(alpha = 0.93f)
        ),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary.copy(alpha = 0.45f)),
        modifier = modifier
            .width(320.dp)
            .fillMaxHeight()
            .graphicsLayer { alpha = panelAlpha }
            .shadow(16.dp, RoundedCornerShape(24.dp))
            .testTag("branch_adjustment_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // HEADER SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تعديلات الفرع",
                        color = GoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Undo button
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "تراجع",
                            tint = if (canUndo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Redo button
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "إعادة",
                            tint = if (canRedo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Close button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            HorizontalDivider(
                color = GoldPrimary.copy(alpha = 0.25f),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // BODY SCROLLABLE OPTIONS
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. BRANCH NAME SECTION (اسم الفرع)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "اسم الفرع في الشجرة",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = branchNameText,
                                onValueChange = {
                                    branchNameText = it
                                    onUpdateElement(element.copy(branchName = it))
                                },
                                placeholder = { Text("إدخال اسم العائلة...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
                                singleLine = true,
                                enabled = !element.isLocked,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GoldPrimary.copy(alpha = 0.4f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                            )

                            if (branchNameText.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        branchNameText = ""
                                        onUpdateElement(element.copy(branchName = ""))
                                    },
                                    enabled = !element.isLocked,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "مسح", tint = Color.Red.copy(alpha = 0.8f))
                                }
                            }
                        }
                    }
                }

                // 2. DIMENSIONS SLIDERS
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "خصائص أبعاد الفرع الأساسية",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // LENGTH (الطول)
                    AdjustmentSliderItem(
                        label = "الطول",
                        value = element.length,
                        valueRange = 0.4f..2.5f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(length = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // THICKNESS (السمك)
                    AdjustmentSliderItem(
                        label = "السمك",
                        value = element.thickness,
                        valueRange = 0.4f..2.5f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(thickness = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // ROTATION (التدوير)
                    AdjustmentSliderItem(
                        label = "التدوير",
                        value = element.rotation,
                        valueRange = 0f..360f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(rotation = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // SHEAR/TILT (الإمالة)
                    AdjustmentSliderItem(
                        label = "الإمالة",
                        value = element.tilt,
                        valueRange = -45f..45f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(tilt = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // TIP TAPER (نحافة الرأس)
                    AdjustmentSliderItem(
                        label = "نحافة الرأس",
                        value = element.tipTaper,
                        valueRange = 0.3f..2.0f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(tipTaper = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // OPACITY (الشفافية)
                    AdjustmentSliderItem(
                        label = "الشفافية",
                        value = element.opacity,
                        valueRange = 0.1f..1.0f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(opacity = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )
                }

                // 3. BRANCH SHAPE PRESETS (تغيير شكل الفرع)
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "شكل الفرع الطبيعي",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    val shapes = listOf(
                        "مستقيم" to 0,
                        "منحني قليلًا" to 1,
                        "منحني بشدة" to 2,
                        "متموج" to 3,
                        "ملتوي" to 4,
                        "فرع قديم" to 5
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        shapes.forEach { (label, preset) ->
                            val isSelected = element.branchShapePreset == preset
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) GoldPrimary else TealMedium.copy(alpha = 0.5f))
                                    .clickable {
                                        onUpdateElement(
                                            element.copy(
                                                branchShapePreset = preset,
                                                deform = if (preset in 3..4) 0.5f else 0f
                                            )
                                        )
                                    }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) TealDeep else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (element.branchShapePreset in 3..4) {
                        AdjustmentSliderItem(
                            label = "تموج أو التواء الفرع",
                            value = element.deform,
                            valueRange = 0f..1f,
                            onValueChange = {
                                onUpdateElement(element.copy(deform = it))
                            },
                            onValueChangeFinished = {}
                        )
                    }
                }

                // 4. WOOD COLORS (ألوان الخشب)
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ألوان الخشب والتدرجات",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    val woodColors = listOf(
                        listOf(Color(0xFFE0A96D), Color(0xFFD29054), Color(0xFF9C663C)), // بني فاتح
                        listOf(Color(0xFF8D6E63), Color(0xFF795548), Color(0xFF5D4037)), // بني متوسط
                        listOf(Color(0xFF5D4037), Color(0xFF4E342E), Color(0xFF3E2723)), // بني غامق
                        listOf(Color(0xFF5C4033), Color(0xFF3D2314), Color(0xFF1F100A)), // خشب قديم
                        listOf(Color(0xFF3B2F2F), Color(0xFF2E1C1C), Color(0xFF1C0D0D)), // خشب رطب
                        listOf(Color(0xFFB0BEC5), Color(0xFF78909C), Color(0xFF37474F))  // رمادي
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        woodColors.forEachIndexed { idx, colors ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Brush.verticalGradient(colors))
                                    .border(
                                        width = if (element.woodColorPreset == idx) 2.dp else 1.dp,
                                        color = if (element.woodColorPreset == idx) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onUpdateElement(element.copy(woodColorPreset = idx))
                                    }
                            )
                        }

                        // Custom color indicator
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Red, Color.Green, Color.Blue)
                                    )
                                )
                                .border(
                                    width = if (element.woodColorPreset == 6) 2.dp else 1.dp,
                                    color = if (element.woodColorPreset == 6) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable {
                                    showColorPicker = !showColorPicker
                                    onUpdateElement(element.copy(woodColorPreset = 6))
                                }
                        ) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }

                    if (showColorPicker) {
                        // Quick palette for custom wood selection
                        val customPalette = listOf(
                            Color(0xFFE67E22), Color(0xFFF1C40F), Color(0xFF2ECC71),
                            Color(0xFF3498DB), Color(0xFF9B59B6), Color(0xFF1ABC9C),
                            Color(0xFFE74C3C), Color(0xFF95A5A6), Color(0xFFF39C12)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            customPalette.forEach { color ->
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (element.customWoodColor == color.toArgb().toLong()) 2.dp else 0.dp,
                                            color = Color.White,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onUpdateElement(
                                                element.copy(
                                                    woodColorPreset = 6,
                                                    customWoodColor = color.toArgb().toLong()
                                                )
                                            )
                                        }
                                )
                            }
                        }
                    }
                }

                // 5. EFFECTS (التأثيرات)
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "التأثيرات الجمالية وعقد اللحاء",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Crack amount
                    AdjustmentSliderItem(
                        label = "تشققات اللحاء",
                        value = element.cracks,
                        valueRange = 0f..1f,
                        onValueChange = {
                            onUpdateElement(element.copy(cracks = it))
                        },
                        onValueChangeFinished = {}
                    )

                    // Roughness amount
                    AdjustmentSliderItem(
                        label = "خشونة اللحاء",
                        value = element.roughness,
                        valueRange = 0f..1f,
                        onValueChange = {
                            onUpdateElement(element.copy(roughness = it))
                        },
                        onValueChangeFinished = {}
                    )

                    // Smoothness amount
                    AdjustmentSliderItem(
                        label = "نعومة اللحاء",
                        value = element.smoothness,
                        valueRange = 0f..1f,
                        onValueChange = {
                            onUpdateElement(element.copy(smoothness = it))
                        },
                        onValueChangeFinished = {}
                    )

                    // Wood knots count
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("عقد خشبية في الجذع/الفرع", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (0..4).forEach { count ->
                                val isSelected = element.woodKnots == count
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) GoldPrimary else TealMedium.copy(alpha = 0.5f))
                                        .clickable {
                                            onUpdateElement(element.copy(woodKnots = count))
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = count.toString(),
                                        color = if (isSelected) TealDeep else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Toggles Row
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val effects = listOf(
                            "ظل داخلي" to element.innerShadow,
                            "ظل خارجي" to element.outerShadow,
                            "تأثير ثلاثي الأبعاد" to element.is3d,
                            "لمعان خفيف" to element.shine
                        )

                        effects.forEach { (label, active) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) GoldPrimary else TealMedium.copy(alpha = 0.4f))
                                    .clickable {
                                        when (label) {
                                            "ظل داخلي" -> onUpdateElement(element.copy(innerShadow = !element.innerShadow))
                                            "ظل خارجي" -> onUpdateElement(element.copy(outerShadow = !element.outerShadow))
                                            "تأثير ثلاثي الأبعاد" -> onUpdateElement(element.copy(is3d = !element.is3d))
                                            "لمعان خفيف" -> onUpdateElement(element.copy(shine = !element.shine))
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (active) TealDeep else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 6. CONNECTION CIRCLE CONTROLS (التحكم بدائرة الاتصال)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.25f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "التحكم بنقطة اتصال الفروع الجديدة",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // Visibility Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("إظهار نقطة الاتصال الصفراء", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            Switch(
                                checked = element.connCircleVisible,
                                onCheckedChange = { onUpdateElement(element.copy(connCircleVisible = it)) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = GoldPrimary,
                                    checkedTrackColor = GoldPrimary.copy(alpha = 0.3f)
                                )
                            )
                        }

                        if (element.connCircleVisible) {
                            // Circle Size Slider
                            AdjustmentSliderItem(
                                label = "حجم دائرة الاتصال",
                                value = element.connCircleSize,
                                valueRange = 8f..24f,
                                onValueChange = { onUpdateElement(element.copy(connCircleSize = it)) },
                                onValueChangeFinished = {}
                            )

                            // Color Picker Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("لون الدائرة:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                val colors = listOf(0xFFFFF59D, 0xFFFFCC80, 0xFF81C784, 0xFF64B5F6, 0xFFE1BEE7)
                                colors.forEach { colorVal ->
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color(colorVal))
                                            .border(
                                                width = if (element.connCircleColor == colorVal) 2.dp else 0.dp,
                                                color = Color.White,
                                                shape = CircleShape
                                            )
                                            .clickable {
                                                onUpdateElement(element.copy(connCircleColor = colorVal))
                                            }
                                    )
                                }
                            }

                            // Circle Direction Offset Slider (تدوير اتجاه نقطة الاتصال)
                            AdjustmentSliderItem(
                                label = "تدوير اتجاه نقطة الاتصال",
                                value = element.connDirectionOffset,
                                valueRange = -180f..180f,
                                onValueChange = { onUpdateElement(element.copy(connDirectionOffset = it)) },
                                onValueChangeFinished = {}
                            )

                            // Flips & Invert Row (قلب أفقي، عمودي، وعكس اتجاه نقطة الاتصال)
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val toggles = listOf(
                                    "قلب أفقي" to element.connFlipH,
                                    "قلب عمودي" to element.connFlipV,
                                    "عكس الاتجاه" to element.connInvertDir
                                )
                                toggles.forEach { (label, isActive) ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isActive) GoldPrimary else TealMedium.copy(alpha = 0.4f))
                                            .clickable {
                                                when (label) {
                                                    "قلب أفقي" -> onUpdateElement(element.copy(connFlipH = !element.connFlipH))
                                                    "قلب عمودي" -> onUpdateElement(element.copy(connFlipV = !element.connFlipV))
                                                    "عكس الاتجاه" -> onUpdateElement(element.copy(connInvertDir = !element.connInvertDir))
                                                }
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (isActive) TealDeep else Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 7. ADD NEW CHILD ELEMENTS (إضافة عناصر متصلة جديدة)
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onAddChildBranch,
                        enabled = !element.isLocked,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.AccountTree, contentDescription = null, tint = TealDeep)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة فرع جديد متصل", color = TealDeep, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onAddChildLeaf,
                        enabled = !element.isLocked,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.Eco, contentDescription = null, tint = TealDeep)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة ورقة جديدة متصلة", color = TealDeep, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                HorizontalDivider(color = GoldPrimary.copy(alpha = 0.15f))

                // 8. ACTION CONTROLS & UTILITIES
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Copy & Paste Settings Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onCopySettings(element) },
                            colors = ButtonDefaults.buttonColors(containerColor = TealMedium.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = GoldLight, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ الخصائص", color = GoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onPasteSettings(element.id) },
                            enabled = hasCopiedSettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasCopiedSettings) TealMedium.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.05f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, tint = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.2f), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("لصق الخصائص", color = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.25f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Lock & Show/Hide Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Lock state
                        Button(
                            onClick = { onUpdateElement(element.copy(isLocked = !element.isLocked)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (element.isLocked) Color(0xFFC0392B).copy(alpha = 0.25f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (element.isLocked) Color.Red else GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isLocked) "إلغاء قفل الفرع" else "قفل الفرع",
                                color = if (element.isLocked) Color.Red else GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Visibility state
                        Button(
                            onClick = { onUpdateElement(element.copy(isVisible = !element.isVisible)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!element.isVisible) Color(0xFF7F8C8D).copy(alpha = 0.2f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isVisible) "إخفاء الفرع" else "إظهار الفرع",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Reset Default Values button
                    Button(
                        onClick = {
                            onUpdateElement(
                                element.copy(
                                    scale = 1.0f,
                                    rotation = 0f,
                                    length = 1.0f,
                                    thickness = 1.0f,
                                    tilt = 0f,
                                    tipTaper = 1.0f,
                                    deform = 0f,
                                    woodColorPreset = 0,
                                    effectsPreset = 0,
                                    isLocked = false,
                                    isVisible = true,
                                    branchName = "",
                                    branchShapePreset = 0,
                                    customWoodColor = null,
                                    cracks = 0f,
                                    woodKnots = 0,
                                    outerShadow = false,
                                    is3d = false,
                                    shine = false,
                                    opacity = 1.0f,
                                    connCircleVisible = true,
                                    connCircleSize = 14f,
                                    connCircleColor = 0xFFFFF59D
                                )
                            )
                            branchNameText = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = GoldLight, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إعادة القيم الافتراضية", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Delete entire Branch button (prompts with dialog)
            Button(
                onClick = { showDeleteConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC0392B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("حذف الفرع بالكامل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}
