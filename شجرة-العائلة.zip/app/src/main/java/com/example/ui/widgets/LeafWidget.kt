package com.example.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CanvasElement

@Composable
fun LeafWidget(
    element: CanvasElement = CanvasElement(type = com.example.ui.screens.ElementType.LEAF, x = 0f, y = 0f),
    modifier: Modifier = Modifier,
    isSelected: Boolean = false
) {
    Box(
        modifier = modifier
            .size(100.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawLeafVectorAdvanced(size.width, size.height, element, isSelected)
        }

        // Draw leaf name centered inside
        if (element.leafName.isNotEmpty() && element.isVisible) {
            val lengthLimit = if (element.thickness < 0.8f) 6 else 12
            val displayText = if (element.leafName.length > lengthLimit) {
                element.leafName.take(lengthLimit) + ".."
            } else {
                element.leafName
            }

            val baseFontSize = when {
                displayText.length > 8 -> 8.sp
                displayText.length > 5 -> 10.sp
                else -> 12.sp
            }

            // Scale font size based on element length and thickness slightly
            val density = LocalDensity.current
            val leafWidthPx = with(density) { 100.dp.toPx() } * element.thickness
            val maxTextWidth = (leafWidthPx * 0.5f).coerceIn(40f, 200f)

            Text(
                text = displayText,
                color = Color.White.copy(alpha = element.leafOpacity.coerceIn(0.2f, 1.0f)),
                fontSize = baseFontSize,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .widthIn(max = (maxTextWidth / 2.5f).dp)
                    .padding(horizontal = 4.dp)
            )
        }
    }
}

fun bezierX(p0: Float, p1: Float, p2: Float, p3: Float, t: Float): Float {
    val mt = 1f - t
    return mt * mt * mt * p0 + 3f * mt * mt * t * p1 + 3f * mt * t * t * p2 + t * t * t * p3
}

fun bezierY(p0: Float, p1: Float, p2: Float, p3: Float, t: Float): Float {
    val mt = 1f - t
    return mt * mt * mt * p0 + 3f * mt * mt * t * p1 + 3f * mt * t * t * p2 + t * t * t * p3
}

fun DrawScope.drawLeafVectorAdvanced(
    width: Float,
    height: Float,
    element: CanvasElement,
    isSelected: Boolean
) {
    val wFactor = element.thickness.coerceIn(0.4f, 2.5f)
    val hFactor = element.length.coerceIn(0.4f, 2.5f)

    // Base colors based on color preset
    val leafColors = when (element.leafColorPreset) {
        0 -> listOf(Color(0xFF81C784), Color(0xFFA5D6A7)) // Light Green
        1 -> listOf(Color(0xFF4CAF50), Color(0xFF81C784)) // Natural Green
        2 -> listOf(Color(0xFF1B5E20), Color(0xFF2E7D32)) // Dark Green
        3 -> listOf(Color(0xFFFDD835), Color(0xFFFFF59D)) // Yellow
        4 -> listOf(Color(0xFFFB8C00), Color(0xFFFFCC80)) // Orange
        5 -> listOf(Color(0xFFD84315), Color(0xFFFF8A65)) // Autumn Red
        6 -> listOf(Color(0xFF8D6E63), Color(0xFFBCAAA4)) // Brown
        else -> listOf(Color(0xFF4CAF50), Color(0xFF81C784))
    }

    val baseColor = if (element.customLeafColor != null) Color(element.customLeafColor) else leafColors[0]
    val accentColor = if (element.customLeafColor != null) {
        // Compute a lighter variant of the custom color
        Color(
            red = (baseColor.red * 1.2f).coerceIn(0f, 1f),
            green = (baseColor.green * 1.2f).coerceIn(0f, 1f),
            blue = (baseColor.blue * 1.2f).coerceIn(0f, 1f),
            alpha = baseColor.alpha
        )
    } else leafColors[1]

    val finalOpacity = element.leafOpacity.coerceIn(0f, 1.0f)
    val leafBrush = Brush.verticalGradient(
        colors = listOf(
            baseColor.copy(alpha = finalOpacity),
            accentColor.copy(alpha = finalOpacity)
        )
    )

    val bX = width * 0.5f
    val bY = height * 0.92f
    val tX = width * 0.5f
    val tY = height * (0.92f - 0.84f * hFactor)

    // Leaf base shape path builder
    val leafPath = Path()

    when (element.leafShapePreset) {
        0 -> { // Natural
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.45f * wFactor), height * (0.92f - 0.22f * hFactor),
                    width * (0.5f - 0.42f * wFactor), height * (0.92f - 0.67f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.42f * wFactor), height * (0.92f - 0.67f * hFactor),
                    width * (0.5f + 0.45f * wFactor), height * (0.92f - 0.22f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        1 -> { // Oval
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.38f * wFactor), height * (0.92f - 0.15f * hFactor),
                    width * (0.5f - 0.38f * wFactor), height * (0.92f - 0.69f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.38f * wFactor), height * (0.92f - 0.69f * hFactor),
                    width * (0.5f + 0.38f * wFactor), height * (0.92f - 0.15f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        2 -> { // Long
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.18f * wFactor), height * (0.92f - 0.25f * hFactor),
                    width * (0.5f - 0.18f * wFactor), height * (0.92f - 0.65f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.18f * wFactor), height * (0.92f - 0.65f * hFactor),
                    width * (0.5f + 0.18f * wFactor), height * (0.92f - 0.25f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        3 -> { // Wide
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.58f * wFactor), height * (0.92f - 0.25f * hFactor),
                    width * (0.5f - 0.58f * wFactor), height * (0.92f - 0.65f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.58f * wFactor), height * (0.92f - 0.65f * hFactor),
                    width * (0.5f + 0.58f * wFactor), height * (0.92f - 0.25f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        4 -> { // Pointed
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.45f * wFactor), height * (0.92f - 0.20f * hFactor),
                    width * (0.5f - 0.22f * wFactor), height * (0.92f - 0.75f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.22f * wFactor), height * (0.92f - 0.75f * hFactor),
                    width * (0.5f + 0.45f * wFactor), height * (0.92f - 0.20f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        5 -> { // Round
            leafPath.apply {
                moveTo(bX, bY)
                cubicTo(
                    width * (0.5f - 0.52f * wFactor), height * (0.92f - 0.25f * hFactor),
                    width * (0.5f - 0.52f * wFactor), height * (0.92f - 0.65f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.52f * wFactor), height * (0.92f - 0.65f * hFactor),
                    width * (0.5f + 0.52f * wFactor), height * (0.92f - 0.25f * hFactor),
                    bX, bY
                )
                close()
            }
        }
        6 -> { // Heart (Cordate)
            leafPath.apply {
                moveTo(bX, bY - 6f * hFactor)
                cubicTo(
                    width * (0.5f - 0.62f * wFactor), bY,
                    width * (0.5f - 0.55f * wFactor), height * (0.92f - 0.60f * hFactor),
                    tX, tY
                )
                cubicTo(
                    width * (0.5f + 0.55f * wFactor), height * (0.92f - 0.60f * hFactor),
                    width * (0.5f + 0.62f * wFactor), bY,
                    bX, bY - 6f * hFactor
                )
                close()
            }
        }
        7 -> { // Toothed (Jagged serrated rose leaf)
            leafPath.apply {
                moveTo(bX, bY)
                val steps = 14
                for (i in 1..steps) {
                    val t = i / steps.toFloat()
                    val cx = bezierX(bX, width * (0.5f - 0.45f * wFactor), width * (0.5f - 0.42f * wFactor), tX, t)
                    val cy = bezierY(bY, height * (0.92f - 0.22f * hFactor), height * (0.92f - 0.67f * hFactor), tY, t)
                    
                    val jagged = if (i % 2 == 0 && i < steps) {
                        -4f * wFactor
                    } else 0f
                    lineTo(cx + jagged, cy)
                }
                for (i in steps downTo 0) {
                    val t = i / steps.toFloat()
                    val cx = bezierX(bX, width * (0.5f + 0.45f * wFactor), width * (0.5f + 0.42f * wFactor), tX, t)
                    val cy = bezierY(bY, height * (0.92f - 0.22f * hFactor), height * (0.92f - 0.67f * hFactor), tY, t)
                    
                    val jagged = if (i % 2 == 0 && i > 0 && i < steps) {
                        4f * wFactor
                    } else 0f
                    lineTo(cx + jagged, cy)
                }
                close()
            }
        }
    }

    // 1. Draw soft shadow if enabled
    if (element.leafShadow) {
        val shadowPath = Path()
        shadowPath.addPath(leafPath, Offset(4f, 4f))
        drawPath(
            path = shadowPath,
            color = Color.Black.copy(alpha = 0.2f * finalOpacity)
        )
    }

    // 2. Draw leaf filled body
    drawPath(
        path = leafPath,
        brush = leafBrush
    )

    // 3. Draw 3D Crease/Fold Shade if enabled
    if (element.leaf3d) {
        // Darken the left half of the leaf
        clipPath(leafPath) {
            drawRect(
                color = Color.Black.copy(alpha = 0.15f * finalOpacity),
                topLeft = Offset(0f, 0f),
                size = androidx.compose.ui.geometry.Size(bX, height)
            )
        }
    }

    // 4. Draw Shine if enabled
    if (element.leafShine) {
        clipPath(leafPath) {
            val shineBrush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.4f * finalOpacity), Color.Transparent),
                center = Offset(bX - 15f * wFactor, tY + (bY - tY) * 0.3f),
                radius = 30f * wFactor
            )
            drawCircle(
                brush = shineBrush,
                center = Offset(bX - 15f * wFactor, tY + (bY - tY) * 0.3f),
                radius = 30f * wFactor
            )
        }
    }

    // 5. Draw Veins based on Vein Clarity
    if (element.leafVeinClarity > 0.05f) {
        val veinAlpha = element.leafVeinClarity.coerceIn(0f, 1.0f) * finalOpacity
        val mainVeinColor = Color.White.copy(alpha = 0.45f * veinAlpha)
        val minorVeinColor = Color.White.copy(alpha = 0.28f * veinAlpha)

        // Draw central main vein
        val centralVein = Path().apply {
            moveTo(bX, bY)
            lineTo(tX, tY)
        }
        drawPath(
            path = centralVein,
            color = mainVeinColor,
            style = Stroke(width = 2.5f * wFactor, cap = StrokeCap.Round)
        )

        // Draw symmetrical diagonal minor veins
        val veinsPath = Path().apply {
            val steps = 3
            for (i in 1..steps) {
                val ratio = i / (steps + 1f)
                val vy = bY - (bY - tY) * ratio
                
                // Left vein
                moveTo(bX, vy)
                quadraticTo(
                    bX - 18f * wFactor, vy - 5f * hFactor,
                    bX - 35f * wFactor, vy - 15f * hFactor
                )

                // Right vein
                moveTo(bX, vy)
                quadraticTo(
                    bX + 18f * wFactor, vy - 5f * hFactor,
                    bX + 35f * wFactor, vy - 15f * hFactor
                )
            }
        }

        clipPath(leafPath) {
            drawPath(
                path = veinsPath,
                color = minorVeinColor,
                style = Stroke(width = 1.2f * wFactor, cap = StrokeCap.Round)
            )
        }
    }

    // 6. Stroke boundary if edge smoothing or selection is active
    val borderStrokeWidth = if (isSelected) 2.dp.toPx() else (1f - element.leafEdgeSmoothing).coerceIn(0.5f, 1.5f).dp.toPx()
    val borderColor = if (isSelected) {
        Color(0xFFFFF176).copy(alpha = finalOpacity) // bright yellow for selection
    } else {
        baseColor.copy(alpha = 0.4f * finalOpacity * element.leafEdgeSmoothing.coerceIn(0.2f, 1.0f))
    }
    
    drawPath(
        path = leafPath,
        color = borderColor,
        style = Stroke(width = borderStrokeWidth)
    )
}
