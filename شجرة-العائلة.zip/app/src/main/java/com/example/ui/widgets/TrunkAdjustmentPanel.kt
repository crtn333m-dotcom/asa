package com.example.ui.widgets

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CanvasElement
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrunkAdjustmentPanel(
    element: CanvasElement,
    onUpdateElement: (CanvasElement) -> Unit,
    onDeleteElement: () -> Unit,
    onClose: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onCopySettings: (CanvasElement) -> Unit,
    onPasteSettings: (String) -> Unit,
    hasCopiedSettings: Boolean,
    onAddChildBranch: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditingBySlider by remember { mutableStateOf(false) }
    var newNameText by remember { mutableStateOf("") }
    var editingNameIndex by remember { mutableStateOf<Int?>(null) }
    var editingNameText by remember { mutableStateOf("") }

    val panelAlpha by animateFloatAsState(
        targetValue = if (isEditingBySlider) 0.60f else 1.0f,
        label = "PanelOpacityAnimation"
    )

    Card(
        colors = CardDefaults.cardColors(
            containerColor = TealDeep.copy(alpha = 0.93f)
        ),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary.copy(alpha = 0.45f)),
        modifier = modifier
            .width(320.dp)
            .fillMaxHeight()
            .graphicsLayer { alpha = panelAlpha }
            .shadow(16.dp, RoundedCornerShape(24.dp))
            .testTag("trunk_adjustment_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // HEADER SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تعديلات الجذع",
                        color = GoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Undo button
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "تراجع",
                            tint = if (canUndo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Redo button
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "إعادة",
                            tint = if (canRedo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Close button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            HorizontalDivider(
                color = GoldPrimary.copy(alpha = 0.25f),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // BODY SCROLLABLE OPTIONS
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. NAMES SECTION (قسم الأسماء)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "أسماء العائلة داخل الجذع (${element.names.size}/10)",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Add Name Field
                        if (element.names.size < 10) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = newNameText,
                                    onValueChange = { newNameText = it },
                                    placeholder = { Text("إضافة اسم...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
                                    singleLine = true,
                                    enabled = !element.isLocked,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.4f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(52.dp)
                                )

                                Button(
                                    onClick = {
                                        if (newNameText.isNotBlank()) {
                                            val updated = element.names + newNameText.trim()
                                            onUpdateElement(element.copy(names = updated))
                                            newNameText = ""
                                        }
                                    },
                                    enabled = !element.isLocked,
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    modifier = Modifier.height(38.dp)
                                ) {
                                    Text("حفظ", color = TealDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        } else {
                            Text(
                                text = "لقد وصلت للحد الأقصى (10 أسماء)",
                                color = Color.Red.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Existing Names List
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            element.names.forEachIndexed { index, name ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(TealDeep.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (editingNameIndex == index) {
                                        // Inline editing name field
                                        OutlinedTextField(
                                            value = editingNameText,
                                            onValueChange = { editingNameText = it },
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = GoldPrimary,
                                                unfocusedBorderColor = GoldPrimary.copy(alpha = 0.4f),
                                                focusedTextColor = Color.White,
                                                unfocusedTextColor = Color.White
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                        )

                                        Spacer(modifier = Modifier.width(6.dp))

                                        IconButton(
                                            onClick = {
                                                if (editingNameText.isNotBlank()) {
                                                    val mutable = element.names.toMutableList()
                                                    mutable[index] = editingNameText.trim()
                                                    onUpdateElement(element.copy(names = mutable))
                                                    editingNameIndex = null
                                                }
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = "تأكيد", tint = Color.Green)
                                        }
                                    } else {
                                        // Standard display
                                        Text(
                                            text = "${index + 1}. $name",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            modifier = Modifier.weight(1f)
                                        )

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Move Up button
                                            IconButton(
                                                onClick = {
                                                    if (index > 0) {
                                                        val mutable = element.names.toMutableList()
                                                        val temp = mutable[index]
                                                        mutable[index] = mutable[index - 1]
                                                        mutable[index - 1] = temp
                                                        onUpdateElement(element.copy(names = mutable))
                                                    }
                                                },
                                                enabled = index > 0,
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ArrowUpward,
                                                    contentDescription = "تحريك لأعلى",
                                                    tint = if (index > 0) GoldPrimary else Color.White.copy(alpha = 0.15f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Move Down button
                                            IconButton(
                                                onClick = {
                                                    if (index < element.names.size - 1) {
                                                        val mutable = element.names.toMutableList()
                                                        val temp = mutable[index]
                                                        mutable[index] = mutable[index + 1]
                                                        mutable[index + 1] = temp
                                                        onUpdateElement(element.copy(names = mutable))
                                                    }
                                                },
                                                enabled = index < element.names.size - 1,
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ArrowDownward,
                                                    contentDescription = "تحريك لأسفل",
                                                    tint = if (index < element.names.size - 1) GoldPrimary else Color.White.copy(alpha = 0.15f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Edit button
                                            IconButton(
                                                onClick = {
                                                    editingNameIndex = index
                                                    editingNameText = name
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Edit,
                                                    contentDescription = "تعديل الاسم",
                                                    tint = GoldPrimary,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Delete button
                                            IconButton(
                                                onClick = {
                                                    val updated = element.names.filterIndexed { i, _ -> i != index }
                                                    onUpdateElement(element.copy(names = updated))
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "حذف الاسم",
                                                    tint = Color.Red.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. SLIDERS SECTION (خصائص التعديل)
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "خصائص أبعاد الجذع",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // LENGTH (الطول)
                    AdjustmentSliderItem(
                        label = "الطول",
                        value = element.length,
                        valueRange = 0.5f..2.2f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(length = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // THICKNESS (السمك)
                    AdjustmentSliderItem(
                        label = "السمك",
                        value = element.thickness,
                        valueRange = 0.5f..2.2f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(thickness = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // ROTATION (التدوير)
                    AdjustmentSliderItem(
                        label = "التدوير",
                        value = element.rotation,
                        valueRange = 0f..360f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(rotation = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // SHEAR/TILT (الإمالة)
                    AdjustmentSliderItem(
                        label = "الإمالة",
                        value = element.tilt,
                        valueRange = -45f..45f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(tilt = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // TIP TAPER (نحافة الرأس)
                    AdjustmentSliderItem(
                        label = "نحافة الرأس",
                        value = element.tipTaper,
                        valueRange = 0.4f..1.8f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(tipTaper = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )

                    // DEFORM (تغيير شكل الجذع)
                    AdjustmentSliderItem(
                        label = "تموج الجذع",
                        value = element.deform,
                        valueRange = 0f..1f,
                        onValueChange = {
                            isEditingBySlider = true
                            onUpdateElement(element.copy(deform = it))
                        },
                        onValueChangeFinished = { isEditingBySlider = false },
                        enabled = !element.isLocked
                    )
                }

                // 3. APPEARANCE PRESETS
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ألوان الخشب والتأثيرات",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Wood presets row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("اللون:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        val presets = listOf(
                            listOf(GoldDark, GoldPrimary, GoldLight), // Classic Gold
                            listOf(Color(0xFF4A1E1B), Color(0xFF8B2500), Color(0xFFCD5B45)), // Mahogany Rose
                            listOf(Color(0xFF2B1B17), Color(0xFF4E3629), Color(0xFF8B5A2B)), // Ancient Oak
                            listOf(Color(0xFF2C3E50), Color(0xFF7F8C8D), Color(0xFFBDC3C7)), // Birch Silver
                            listOf(Color(0xFF0F251E), Color(0xFF1E5631), Color(0xFF4C9A2A))  // Emerald Pine
                        )

                        presets.forEachIndexed { idx, colors ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Brush.verticalGradient(colors))
                                    .border(
                                        width = if (element.woodColorPreset == idx) 2.dp else 1.dp,
                                        color = if (element.woodColorPreset == idx) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onUpdateElement(element.copy(woodColorPreset = idx))
                                    }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Effects presets row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("التأثير:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)

                        val effectsList = listOf("افتراضي", "توهج مائي", "إطار ملكي")
                        effectsList.forEachIndexed { idx, label ->
                            val isSelected = element.effectsPreset == idx
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) GoldPrimary else TealMedium.copy(alpha = 0.5f))
                                    .clickable {
                                        onUpdateElement(element.copy(effectsPreset = idx))
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) TealDeep else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = GoldPrimary.copy(alpha = 0.15f))

                // 4. ACTION CONTROLS & UTILITIES
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Copy & Paste Settings Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onCopySettings(element) },
                            colors = ButtonDefaults.buttonColors(containerColor = TealMedium.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = GoldLight, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ الخصائص", color = GoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onPasteSettings(element.id) },
                            enabled = hasCopiedSettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasCopiedSettings) TealMedium.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.05f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, tint = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.2f), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("لصق الخصائص", color = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.25f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Lock & Show/Hide Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Lock state
                        Button(
                            onClick = { onUpdateElement(element.copy(isLocked = !element.isLocked)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (element.isLocked) Color(0xFFC0392B).copy(alpha = 0.25f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (element.isLocked) Color.Red else GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isLocked) "إلغاء قفل الجذع" else "قفل الجذع",
                                color = if (element.isLocked) Color.Red else GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Visibility state
                        Button(
                            onClick = { onUpdateElement(element.copy(isVisible = !element.isVisible)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!element.isVisible) Color(0xFF7F8C8D).copy(alpha = 0.2f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isVisible) "إخفاء الجذع" else "إظهار الجذع",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Add Branch button
                    Button(
                        onClick = onAddChildBranch,
                        enabled = !element.isLocked,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.AccountTree, contentDescription = null, tint = TealDeep, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة فرع جديد متصل", color = TealDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Reset Default Values button
                    Button(
                        onClick = {
                            onUpdateElement(
                                element.copy(
                                    scale = 1.0f,
                                    rotation = 0f,
                                    length = 1.0f,
                                    thickness = 1.0f,
                                    tilt = 0f,
                                    tipTaper = 1.0f,
                                    deform = 0f,
                                    woodColorPreset = 0,
                                    effectsPreset = 0,
                                    isLocked = false,
                                    isVisible = true
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = GoldLight, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إعادة القيم الافتراضية", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Delete entire Trunk button (can only create new trunk after deletion)
            Button(
                onClick = onDeleteElement,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC0392B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("حذف الجذع بالكامل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun AdjustmentSliderItem(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = if (enabled) 1.0f else 0.45f }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(String.format("%.2f", value), color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Slider(
            value = value,
            valueRange = valueRange,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = GoldPrimary,
                activeTrackColor = GoldPrimary,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                disabledThumbColor = Color.Gray,
                disabledActiveTrackColor = Color.Gray
            ),
            modifier = Modifier.height(30.dp)
        )
    }
}
