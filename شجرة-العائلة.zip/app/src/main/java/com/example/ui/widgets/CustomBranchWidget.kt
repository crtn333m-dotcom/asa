package com.example.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CanvasElement
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun CustomBranchWidget(
    element: CanvasElement,
    isSelected: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = element.opacity.coerceIn(0.1f, 1.0f)
            },
        contentAlignment = Alignment.Center
    ) {
        // Resolve wood colors based on presets
        val colors = when (element.woodColorPreset) {
            0 -> listOf(Color(0xFFE0A96D), Color(0xFFD29054), Color(0xFF9C663C)) // Light brown
            1 -> listOf(Color(0xFF8D6E63), Color(0xFF795548), Color(0xFF5D4037)) // Medium brown
            2 -> listOf(Color(0xFF5D4037), Color(0xFF4E342E), Color(0xFF3E2723)) // Dark brown
            3 -> listOf(Color(0xFF5C4033), Color(0xFF3D2314), Color(0xFF1F100A)) // Ancient wood
            4 -> listOf(Color(0xFF3B2F2F), Color(0xFF2E1C1C), Color(0xFF1C0D0D)) // Wet wood
            5 -> listOf(Color(0xFFB0BEC5), Color(0xFF78909C), Color(0xFF37474F)) // Grey
            6 -> {
                val base = Color(element.customWoodColor ?: 0xFF8D6E63)
                listOf(base.copy(alpha = 0.9f), base, base.copy(red = (base.red * 0.7f).coerceIn(0f, 1f)))
            }
            else -> listOf(GoldDark, GoldPrimary, GoldLight)
        }

        val brush = Brush.verticalGradient(colors)

        // Draw Branch using Vector Paths
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val len = element.length.coerceIn(0.4f, 2.5f)
            val thick = element.thickness.coerceIn(0.4f, 2.5f)
            val tiltOffset = element.tilt.coerceIn(-45f, 45f) * (width / 100f)
            val taper = element.tipTaper.coerceIn(0.3f, 2.0f)

            // Local coordinates mapping
            val localBaseX = 0.15f * width
            val localBaseY = 0.85f * height

            val localTipX = 0.85f * width + tiltOffset
            val localTipY = localBaseY - (localBaseY - 0.15f * height) * len

            val transformX = { x: Float, y: Float ->
                val relativeY = (height - y) / height
                var tx = x
                // Taper effect towards tip
                tx = localBaseX + (tx - localBaseX) * (1f - (1f - taper) * relativeY)
                // Add wave deform if wavy preset is selected
                if (element.branchShapePreset == 3) {
                    tx += sin(relativeY * Math.PI.toFloat() * 3f) * 10f * element.deform
                } else if (element.branchShapePreset == 4) { // Twisted
                    tx += sin(relativeY * Math.PI.toFloat() * 5f) * 14f * element.deform
                }
                tx
            }

            // Draw Branch Path
            val branchPath = Path().apply {
                // Base thick point
                moveTo(transformX(localBaseX - 10f * thick, localBaseY), localBaseY + 5f * thick)
                
                // Curve to the tapered tip
                val cp1x = transformX(width * 0.45f, height * 0.7f)
                val cp1y = localBaseY - (localBaseY - height * 0.6f) * len
                val cp2x = transformX(width * 0.75f, height * 0.4f)
                val cp2y = localBaseY - (localBaseY - height * 0.35f) * len

                cubicTo(
                    cp1x, cp1y,
                    cp2x, cp2y,
                    transformX(localTipX - 3f * thick * taper, localTipY), localTipY
                )

                lineTo(transformX(localTipX + 3f * thick * taper, localTipY), localTipY)

                // Curve back to base
                cubicTo(
                    transformX(width * 0.7f, height * 0.45f), localBaseY - (localBaseY - height * 0.4f) * len,
                    transformX(width * 0.35f, height * 0.65f), localBaseY - (localBaseY - height * 0.65f) * len,
                    transformX(localBaseX + 10f * thick, localBaseY), localBaseY - 5f * thick
                )
                close()
            }

            // Effects: 3D effect (Outer glow / Shadow)
            if (element.is3d) {
                drawPath(
                    path = branchPath,
                    color = colors.first().copy(alpha = 0.35f),
                    style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Fill main branch body
            drawPath(
                path = branchPath,
                brush = brush
            )

            // Inner Shadow Effect (draw shadow stroke inside branch body)
            if (element.innerShadow) {
                drawPath(
                    path = branchPath,
                    color = Color.Black.copy(alpha = 0.35f),
                    style = Stroke(width = 3.dp.toPx() * thick, cap = StrokeCap.Round)
                )
            }

            // Outer Shadow Effect
            if (element.outerShadow) {
                drawPath(
                    path = branchPath,
                    color = Color.Black.copy(alpha = 0.25f),
                    style = Stroke(width = 4.dp.toPx())
                )
            }

            // Bark Grains & Lines (adjusted by smoothness)
            val grainAlpha = (0.5f * (1f - element.smoothness)).coerceIn(0f, 0.5f)
            val grainColor = colors.last().copy(alpha = grainAlpha)
            val barkPath = Path().apply {
                moveTo(localBaseX, localBaseY)
                quadraticTo(
                    transformX(width * 0.45f, height * 0.6f), localBaseY - (localBaseY - height * 0.55f) * len,
                    localTipX, localTipY
                )
            }
            if (grainAlpha > 0.05f) {
                drawPath(
                    path = barkPath,
                    color = grainColor,
                    style = Stroke(width = 2.dp.toPx() * thick, cap = StrokeCap.Round)
                )
            }

            // Roughness effect (draw small textured marks across the branch if roughness > 0)
            if (element.roughness > 0.05f) {
                val roughColor = colors.last().copy(alpha = (element.roughness * 0.6f).coerceIn(0f, 0.6f))
                for (i in 1..6) {
                    val ratio = i / 7f
                    val rx = transformX(width * (0.25f + ratio * 0.5f), height * (0.75f - ratio * 0.5f))
                    val ry = localBaseY - (localBaseY - (height * (0.7f - ratio * 0.5f))) * len
                    drawLine(
                        color = roughColor,
                        start = Offset(rx - 4f, ry - 4f),
                        end = Offset(rx + 4f, ry + 4f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }

            // Knots effect (small knots drawn along the branch)
            if (element.woodKnots > 0) {
                for (i in 1..element.woodKnots) {
                    val ratio = i / (element.woodKnots + 1f)
                    val kx = transformX(width * (0.2f + ratio * 0.5f), height * (0.8f - ratio * 0.5f))
                    val ky = localBaseY - (localBaseY - (height * (0.75f - ratio * 0.5f))) * len
                    drawCircle(
                        color = colors.last().copy(alpha = 0.7f),
                        radius = 4.dp.toPx() * thick,
                        center = Offset(kx, ky),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
            }

            // Cracks / Rough bark
            if (element.cracks > 0.1f) {
                val crackColor = colors.last().copy(alpha = 0.7f)
                val cx = transformX(width * 0.4f, height * 0.55f)
                val cy = localBaseY - (localBaseY - height * 0.5f) * len
                drawLine(
                    color = crackColor,
                    start = Offset(cx - 5f, cy - 2f),
                    end = Offset(cx + 8f, cy + 4f),
                    strokeWidth = 2.dp.toPx()
                )
                drawLine(
                    color = crackColor,
                    start = Offset(cx - 2f, cy + 10f),
                    end = Offset(cx + 10f, cy + 15f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }

            // Shine effect
            if (element.shine) {
                drawPath(
                    path = barkPath,
                    color = Color.White.copy(alpha = 0.35f),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        // Branch Name Label Overlay
        if (element.branchName.isNotBlank() && element.isVisible) {
            Box(
                modifier = Modifier
                    .offset(y = (-32).dp)
                    .background(CreamBackground.copy(alpha = 0.92f), RoundedCornerShape(6.dp))
                    .border(1.dp, GoldPrimary.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .align(Alignment.Center)
            ) {
                Text(
                    text = element.branchName,
                    color = TealDeep,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Connection point indicator circle (دائرة اتصال الفرع)
        if (isSelected && element.connCircleVisible) {
            // Get local Tip coordinates in DP
            val len = element.length.coerceIn(0.4f, 2.5f)
            val tiltOffset = element.tilt.coerceIn(-45f, 45f)
            val localBaseX = 15f
            val localBaseY = 85f
            
            var localTipX = 85f + tiltOffset
            var localTipY = localBaseY - (localBaseY - 15f) * len

            // Adjust based on shape preset
            when (element.branchShapePreset) {
                1 -> { localTipX -= 5f }
                2 -> { localTipX -= 15f }
                3 -> { localTipX += sin(len * Math.PI.toFloat()) * 8f }
                4 -> { localTipX -= 10f }
                5 -> { localTipX += 5f }
            }

            if (element.connInvertDir) {
                val tempX = localTipX
                val tempY = localTipY
                val baseX = 15f
                val baseY = 85f
                localTipX = baseX - (tempX - baseX)
                localTipY = baseY - (tempY - baseY)
            }

            if (element.connFlipH) {
                localTipX = 100f - localTipX
            }
            if (element.connFlipV) {
                localTipY = 100f - localTipY
            }

            // Apply direction offset rotation relative to center (50, 50)
            val rx = localTipX - 50f
            val ry = localTipY - 50f
            val radOffset = Math.toRadians(element.connDirectionOffset.toDouble()).toFloat()
            val cosOffset = kotlin.math.cos(radOffset)
            val sinOffset = kotlin.math.sin(radOffset)
            
            val finalRx = rx * cosOffset - ry * sinOffset
            val finalRy = rx * sinOffset + ry * cosOffset
            
            val finalTipX = 50f + finalRx
            val finalTipY = 50f + finalRy

            Box(
                modifier = Modifier
                    .size(element.connCircleSize.dp)
                    .offset(
                        x = (finalTipX - 50f).dp,
                        y = (finalTipY - 50f).dp
                    )
                    .shadow(4.dp, CircleShape)
                    .background(Color(element.connCircleColor), CircleShape)
                    .border(1.5.dp, GoldPrimary, CircleShape)
            )
        }
    }
}
