package com.example.ui.widgets

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AmbientGlowingSpecks() {
    val infiniteTransition = rememberInfiniteTransition(label = "Specks")
    
    // Create animated offsets for multiple floating circles
    val floatAnim1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Float1"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Define fixed relative coordinates to avoid recomposition instability
        val specks = listOf(
            Offset(0.15f, 0.25f) to 6.dp,
            Offset(0.85f, 0.15f) to 8.dp,
            Offset(0.30f, 0.65f) to 5.dp,
            Offset(0.75f, 0.75f) to 7.dp,
            Offset(0.50f, 0.40f) to 10.dp,
            Offset(0.10f, 0.85f) to 4.dp,
            Offset(0.90f, 0.90f) to 6.dp
        )

        specks.forEachIndexed { i, (relOffset, radius) ->
            val angleOffset = i * 45f
            val xOffset = sin(floatAnim1 + angleOffset) * 15.dp.toPx()
            val yOffset = cos(floatAnim1 + angleOffset) * 15.dp.toPx()
            
            val finalX = relOffset.x * width + xOffset
            val finalY = relOffset.y * height + yOffset

            drawCircle(
                color = GoldLight.copy(alpha = 0.15f),
                radius = radius.toPx(),
                center = Offset(finalX, finalY)
            )

            // Outer soft glow
            drawCircle(
                color = GoldPrimary.copy(alpha = 0.05f),
                radius = radius.toPx() * 2.2f,
                center = Offset(finalX, finalY)
            )
        }
    }
}
