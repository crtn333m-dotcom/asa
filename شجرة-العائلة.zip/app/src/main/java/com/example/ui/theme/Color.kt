package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Family Tree Golden-Teal Color Scheme
val GoldPrimary = Color(0xFFC5A059)
val GoldLight = Color(0xFFE8D3A7)
val GoldDark = Color(0xFF916F34)

val TealDeep = Color(0xFF0D3B43)
val TealMedium = Color(0xFF145D6A)
val TealLight = Color(0xFF238E9B)

val GreenLeaf = Color(0xFF3B7A57)
val GreenLeafLight = Color(0xFF6EA47F)

val CreamBackground = Color(0xFFF9F6F0)
val CreamSurface = Color(0xFFF3EDE0)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
