package com.example.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary

@Composable
fun BranchWidget(
    modifier: Modifier = Modifier,
    colorOverride: Brush? = null
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        drawBranchVector(size.width, size.height, colorOverride)
    }
}

fun DrawScope.drawBranchVector(width: Float, height: Float, colorOverride: Brush? = null) {
    val branchBrush = colorOverride ?: Brush.linearGradient(
        colors = listOf(GoldDark, GoldPrimary, GoldLight)
    )

    // Branch starts thick at bottom-left and curves elegantly, tapering to a fine tip at top-right
    val branchPath = Path().apply {
        // Base starting point (thick)
        moveTo(width * 0.05f, height * 0.85f)
        
        // Lower graceful curve to the tip
        quadraticTo(
            width * 0.45f, height * 0.75f,
            width * 0.95f, height * 0.20f
        )
        
        // Tapered tip line
        lineTo(width * 0.92f, height * 0.15f)
        
        // Upper curve back to base (thin to thick)
        quadraticTo(
            width * 0.40f, height * 0.60f,
            width * 0.05f, height * 0.65f
        )
        
        close()
    }

    // Fill the branch body
    drawPath(
        path = branchPath,
        brush = branchBrush
    )

    // Inner detail/grain line to give sense of direction and organic flow
    val grainPath = Path().apply {
        moveTo(width * 0.12f, height * 0.73f)
        quadraticTo(
            width * 0.45f, height * 0.65f,
            width * 0.82f, height * 0.28f
        )
    }

    drawPath(
        path = grainPath,
        color = GoldDark.copy(alpha = 0.4f),
        style = Stroke(width = width * 0.03f, cap = StrokeCap.Round)
    )
}
