package com.example.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CanvasElement
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun CustomTrunkWidget(
    element: CanvasElement,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Dynamic wood colors gradient select
        val colors = when (element.woodColorPreset) {
            1 -> listOf(Color(0xFF4A1E1B), Color(0xFF8B2500), Color(0xFFCD5B45)) // Warm Rosewood
            2 -> listOf(Color(0xFF2B1B17), Color(0xFF4E3629), Color(0xFF8B5A2B)) // Ancient Oak
            3 -> listOf(Color(0xFF2C3E50), Color(0xFF7F8C8D), Color(0xFFBDC3C7)) // Mystic Birch
            4 -> listOf(Color(0xFF0F251E), Color(0xFF1E5631), Color(0xFF4C9A2A)) // Emerald Pine
            else -> listOf(GoldDark, GoldPrimary, GoldLight) // Classic Gold
        }

        val brush = Brush.verticalGradient(colors)

        // 1. DRAW TREE TRUNK PATH
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Calculate deform, length, thickness, tilt, tipTaper parameters
            val len = element.length.coerceIn(0.4f, 2.5f)
            val thick = element.thickness.coerceIn(0.4f, 2.5f)
            val tiltOffset = element.tilt.coerceIn(-60f, 60f)
            val taper = element.tipTaper.coerceIn(0.3f, 2.0f)
            val wiggliness = element.deform.coerceIn(0f, 1.0f)

            // Dynamic coordinate transformer to apply real-time modifications directly to the vector
            val transformX = { x: Float, y: Float ->
                val relativeY = y / height
                // Center-based thickness scaling
                val centerX = width * 0.5f
                var tx = centerX + (x - centerX) * thick
                
                // Tilt/Shear offset (larger at the top, zero at the base)
                tx += tiltOffset * (1f - relativeY) * 2f

                // Taper effect for forks/tips (upper half of the trunk)
                if (y < height * 0.5f) {
                    val upperFactor = (height * 0.5f - y) / (height * 0.5f)
                    tx = centerX + (tx - centerX) * (1f - (1f - taper) * upperFactor)
                }

                // Deform/Wiggliness (sine wave variation)
                tx += sin(relativeY * Math.PI.toFloat() * 3f) * wiggliness * 12f

                tx
            }

            val transformY = { y: Float ->
                // Length/height scaling from the base (height) upwards
                height - (height - y) * len
            }

            // Outer glow or shadow effect
            if (element.effectsPreset == 1) {
                // Glow effect draw
                val glowPath = Path().apply {
                    val bX = transformX(width * 0.25f, height)
                    val bY = transformY(height)
                    moveTo(bX, bY)

                    cubicTo(
                        transformX(width * 0.35f, height * 0.8f), transformY(height * 0.8f),
                        transformX(width * 0.38f, height * 0.6f), transformY(height * 0.6f),
                        transformX(transformX(width * 0.40f, height * 0.5f), transformY(height * 0.5f)), transformY(height * 0.5f)
                    )
                    cubicTo(
                        transformX(width * 0.30f, height * 0.35f), transformY(height * 0.35f),
                        transformX(width * 0.15f, height * 0.25f), transformY(height * 0.25f),
                        transformX(width * 0.10f, height * 0.15f), transformY(height * 0.15f)
                    )
                    lineTo(transformX(width * 0.22f, height * 0.10f), transformY(height * 0.10f))
                    cubicTo(
                        transformX(width * 0.30f, height * 0.20f), transformY(height * 0.20f),
                        transformX(width * 0.40f, height * 0.30f), transformY(height * 0.30f),
                        transformX(width * 0.46f, height * 0.42f), transformY(height * 0.42f)
                    )
                    lineTo(transformX(width * 0.54f, height * 0.42f), transformY(height * 0.42f))
                    cubicTo(
                        transformX(width * 0.60f, height * 0.30f), transformY(height * 0.30f),
                        transformX(width * 0.70f, height * 0.20f), transformY(height * 0.20f),
                        transformX(width * 0.78f, height * 0.10f), transformY(height * 0.10f)
                    )
                    lineTo(transformX(width * 0.90f, height * 0.15f), transformY(height * 0.15f))
                    cubicTo(
                        transformX(width * 0.85f, height * 0.25f), transformY(height * 0.25f),
                        transformX(width * 0.70f, height * 0.35f), transformY(height * 0.35f),
                        transformX(width * 0.60f, height * 0.50f), transformY(height * 0.50f)
                    )
                    cubicTo(
                        transformX(width * 0.62f, height * 0.6f), transformY(height * 0.6f),
                        transformX(width * 0.65f, height * 0.8f), transformY(height * 0.8f),
                        transformX(width * 0.75f, height), transformY(height)
                    )
                    close()
                }
                drawPath(
                    path = glowPath,
                    color = colors.last().copy(alpha = 0.25f),
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Primary Trunk Path
            val trunkPath = Path().apply {
                moveTo(transformX(width * 0.25f, height), transformY(height))
                
                cubicTo(
                    transformX(width * 0.35f, height * 0.8f), transformY(height * 0.8f),
                    transformX(width * 0.38f, height * 0.6f), transformY(height * 0.6f),
                    transformX(width * 0.40f, height * 0.5f), transformY(height * 0.5f)
                )
                
                cubicTo(
                    transformX(width * 0.30f, height * 0.35f), transformY(height * 0.35f),
                    transformX(width * 0.15f, height * 0.25f), transformY(height * 0.25f),
                    transformX(width * 0.10f, height * 0.15f), transformY(height * 0.15f)
                )
                
                lineTo(transformX(width * 0.22f, height * 0.10f), transformY(height * 0.10f))
                
                cubicTo(
                    transformX(width * 0.30f, height * 0.20f), transformY(height * 0.20f),
                    transformX(width * 0.40f, height * 0.30f), transformY(height * 0.30f),
                    transformX(width * 0.46f, height * 0.42f), transformY(height * 0.42f)
                )
                
                lineTo(transformX(width * 0.54f, height * 0.42f), transformY(height * 0.42f))
                
                cubicTo(
                    transformX(width * 0.60f, height * 0.30f), transformY(height * 0.30f),
                    transformX(width * 0.70f, height * 0.20f), transformY(height * 0.20f),
                    transformX(width * 0.78f, height * 0.10f), transformY(height * 0.10f)
                )
                
                lineTo(transformX(width * 0.90f, height * 0.15f), transformY(height * 0.15f))
                
                cubicTo(
                    transformX(width * 0.85f, height * 0.25f), transformY(height * 0.25f),
                    transformX(width * 0.70f, height * 0.35f), transformY(height * 0.35f),
                    transformX(width * 0.60f, height * 0.50f), transformY(height * 0.50f)
                )
                
                cubicTo(
                    transformX(width * 0.62f, height * 0.6f), transformY(height * 0.6f),
                    transformX(width * 0.65f, height * 0.8f), transformY(height * 0.8f),
                    transformX(width * 0.75f, height), transformY(height)
                )
                
                close()
            }

            // Fill trunk
            drawPath(
                path = trunkPath,
                brush = brush
            )

            // Royal Gold Border trim preset
            if (element.effectsPreset == 2) {
                drawPath(
                    path = trunkPath,
                    color = GoldLight,
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // 2. DETAILED BARK GRAINS
            val barkPath1 = Path().apply {
                moveTo(transformX(width * 0.5f, height * 0.95f), transformY(height * 0.95f))
                quadraticTo(
                    transformX(width * 0.48f, height * 0.7f), transformY(height * 0.7f),
                    transformX(width * 0.48f, height * 0.45f), transformY(height * 0.45f)
                )
            }
            
            val barkPath2 = Path().apply {
                moveTo(transformX(width * 0.38f, height * 0.9f), transformY(height * 0.9f))
                quadraticTo(
                    transformX(width * 0.42f, height * 0.75f), transformY(height * 0.75f),
                    transformX(width * 0.35f, height * 0.6f), transformY(height * 0.6f)
                )
            }

            val barkPath3 = Path().apply {
                moveTo(transformX(width * 0.62f, height * 0.9f), transformY(height * 0.9f))
                quadraticTo(
                    transformX(width * 0.58f, height * 0.75f), transformY(height * 0.75f),
                    transformX(width * 0.65f, height * 0.6f), transformY(height * 0.6f)
                )
            }

            // Choose grain color based on contrast
            val grainColor = if (element.woodColorPreset == 3) Color(0xFF2C3E50).copy(alpha = 0.4f) else colors.first().copy(alpha = 0.55f)

            drawPath(
                path = barkPath1,
                color = grainColor,
                style = Stroke(width = width * 0.04f * thick, cap = StrokeCap.Round)
            )
            drawPath(
                path = barkPath2,
                color = grainColor,
                style = Stroke(width = width * 0.025f * thick, cap = StrokeCap.Round)
            )
            drawPath(
                path = barkPath3,
                color = grainColor,
                style = Stroke(width = width * 0.025f * thick, cap = StrokeCap.Round)
            )
        }

        // 3. RENDER TEXT NAMES INSIDE THE TRUNK ONLY
        if (element.names.isNotEmpty() && element.isVisible) {
            val orderedNames = element.names.asReversed()
            val len = element.length.coerceIn(0.4f, 2.5f)
            val thick = element.thickness.coerceIn(0.4f, 2.5f)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = (18 * thick).dp) // Constrain side space with thickness
                    .padding(top = (36 / len).dp, bottom = 12.dp), // Constrain vertical space
                contentAlignment = Alignment.BottomCenter
            ) {
                val count = orderedNames.size
                // Dynamic font calculation to auto-shrink names when space is tight or count increases
                val baseSize = (11f * thick).coerceIn(8f, 15f)
                val calculatedSize = (baseSize * 4.2f / (count + 2f) * len).coerceIn(7f, 13f)

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.Bottom)
                ) {
                    orderedNames.forEach { name ->
                        Text(
                            text = name,
                            color = when (element.woodColorPreset) {
                                3 -> Color.White // Silver Birch contrasts beautifully with white text
                                else -> TealDeep // Dark Teal is incredibly elegant against Golden/Warm woods
                            },
                            fontSize = calculatedSize.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .background(
                                    color = if (element.woodColorPreset == 3) {
                                        Color.Black.copy(alpha = 0.55f)
                                    } else {
                                        CreamBackground.copy(alpha = 0.88f)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
