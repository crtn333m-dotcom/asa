package com.example.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary

@Composable
fun TrunkWidget(
    modifier: Modifier = Modifier,
    colorOverride: Brush? = null
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        drawTrunkVector(size.width, size.height, colorOverride)
    }
}

fun DrawScope.drawTrunkVector(width: Float, height: Float, colorOverride: Brush? = null) {
    val trunkBrush = colorOverride ?: Brush.verticalGradient(
        colors = listOf(GoldDark, GoldPrimary, GoldLight)
    )

    // Symmetrical, detailed organic tree trunk
    val trunkPath = Path().apply {
        // Base wide root
        moveTo(width * 0.25f, height)
        
        // Curve up left side
        cubicTo(
            width * 0.35f, height * 0.8f,
            width * 0.38f, height * 0.6f,
            width * 0.40f, height * 0.5f
        )
        
        // Left fork/branch split
        cubicTo(
            width * 0.30f, height * 0.35f,
            width * 0.15f, height * 0.25f,
            width * 0.10f, height * 0.15f
        )
        // Left fork tip
        lineTo(width * 0.22f, height * 0.10f)
        cubicTo(
            width * 0.30f, height * 0.20f,
            width * 0.40f, height * 0.30f,
            width * 0.46f, height * 0.42f
        )
        
        // Inner fork top split
        lineTo(width * 0.54f, height * 0.42f)
        
        // Right fork split
        cubicTo(
            width * 0.60f, height * 0.30f,
            width * 0.70f, height * 0.20f,
            width * 0.78f, height * 0.10f
        )
        // Right fork tip
        lineTo(width * 0.90f, height * 0.15f)
        cubicTo(
            width * 0.85f, height * 0.25f,
            width * 0.70f, height * 0.35f,
            width * 0.60f, height * 0.50f
        )
        
        // Curve down right side
        cubicTo(
            width * 0.62f, height * 0.6f,
            width * 0.65f, height * 0.8f,
            width * 0.75f, height
        )
        
        close()
    }

    // Draw main filled trunk
    drawPath(
        path = trunkPath,
        brush = trunkBrush
    )

    // Realistic detailed bark textures/veins
    val barkPath1 = Path().apply {
        moveTo(width * 0.5f, height * 0.95f)
        quadraticTo(width * 0.48f, height * 0.7f, width * 0.48f, height * 0.45f)
    }
    
    val barkPath2 = Path().apply {
        moveTo(width * 0.38f, height * 0.9f)
        quadraticTo(width * 0.42f, height * 0.75f, width * 0.35f, height * 0.6f)
    }

    val barkPath3 = Path().apply {
        moveTo(width * 0.62f, height * 0.9f)
        quadraticTo(width * 0.58f, height * 0.75f, width * 0.65f, height * 0.6f)
    }

    // Drawing bark details
    drawPath(
        path = barkPath1,
        color = GoldDark.copy(alpha = 0.5f),
        style = Stroke(width = width * 0.04f, cap = StrokeCap.Round)
    )
    drawPath(
        path = barkPath2,
        color = GoldDark.copy(alpha = 0.4f),
        style = Stroke(width = width * 0.03f, cap = StrokeCap.Round)
    )
    drawPath(
        path = barkPath3,
        color = GoldDark.copy(alpha = 0.4f),
        style = Stroke(width = width * 0.03f, cap = StrokeCap.Round)
    )
}
