package com.example.ui.widgets

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CanvasElement
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LeafAdjustmentPanel(
    element: CanvasElement,
    onUpdateElement: (CanvasElement) -> Unit,
    onDeleteElement: () -> Unit,
    onClose: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onCopySettings: (CanvasElement) -> Unit,
    onPasteSettings: (String) -> Unit,
    hasCopiedSettings: Boolean,
    modifier: Modifier = Modifier
) {
    var isEditingBySlider by remember { mutableStateOf(false) }
    var leafNameText by remember { mutableStateOf(element.leafName) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showColorPicker by remember { mutableStateOf(false) }

    val panelAlpha by animateFloatAsState(
        targetValue = if (isEditingBySlider) 0.60f else 1.0f,
        label = "PanelOpacityAnimation"
    )

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف الورقة", color = GoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذه الورقة؟ لا يمكن التراجع عن هذا الإجراء.", color = Color.White, fontSize = 14.sp) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteElement()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                ) {
                    Text("نعم، احذف", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء", color = Color.White)
                }
            },
            containerColor = TealDeep,
            tonalElevation = 6.dp
        )
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = TealDeep.copy(alpha = 0.93f)
        ),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary.copy(alpha = 0.45f)),
        modifier = modifier
            .width(320.dp)
            .fillMaxHeight()
            .graphicsLayer { alpha = panelAlpha }
            .shadow(16.dp, RoundedCornerShape(24.dp))
            .testTag("leaf_adjustment_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // HEADER SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تعديلات الورقة",
                        color = GoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Undo button
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "تراجع",
                            tint = if (canUndo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Redo button
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "إعادة",
                            tint = if (canRedo) GoldPrimary else Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Close button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            HorizontalDivider(
                color = GoldPrimary.copy(alpha = 0.25f),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // BODY SCROLLABLE OPTIONS
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. LEAF NAME SECTION (اسم الورقة)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "اسم الورقة",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = leafNameText,
                                onValueChange = {
                                    leafNameText = it
                                    onUpdateElement(element.copy(leafName = it))
                                },
                                placeholder = { Text("إدخال اسم الورقة...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
                                singleLine = true,
                                enabled = !element.isLocked,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GoldPrimary.copy(alpha = 0.4f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                            )

                            if (leafNameText.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        leafNameText = ""
                                        onUpdateElement(element.copy(leafName = ""))
                                    },
                                    enabled = !element.isLocked,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "مسح الاسم",
                                        tint = Color.Red.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. MAIN PROPERTIES SLIDERS
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "الأبعاد والاتجاه",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        // 2a. Scale (الحجم العام)
                        LeafAdjustmentSliderItem(
                            label = "تكبير وتصغير",
                            value = element.scale,
                            valueRange = 0.4f..3.0f,
                            onValueChange = {
                                isEditingBySlider = true
                                onUpdateElement(element.copy(scale = it))
                            },
                            onValueChangeFinished = { isEditingBySlider = false },
                            enabled = !element.isLocked
                        )

                        // 2b. Length (الطول)
                        LeafAdjustmentSliderItem(
                            label = "الطول",
                            value = element.length,
                            valueRange = 0.4f..2.5f,
                            onValueChange = {
                                isEditingBySlider = true
                                onUpdateElement(element.copy(length = it))
                            },
                            onValueChangeFinished = { isEditingBySlider = false },
                            enabled = !element.isLocked
                        )

                        // 2c. Width (العرض)
                        LeafAdjustmentSliderItem(
                            label = "العرض",
                            value = element.thickness,
                            valueRange = 0.4f..2.5f,
                            onValueChange = {
                                isEditingBySlider = true
                                onUpdateElement(element.copy(thickness = it))
                            },
                            onValueChangeFinished = { isEditingBySlider = false },
                            enabled = !element.isLocked
                        )

                        // 2d. Rotation (التدوير)
                        LeafAdjustmentSliderItem(
                            label = "التدوير",
                            value = element.rotation,
                            valueRange = 0f..360f,
                            onValueChange = {
                                isEditingBySlider = true
                                onUpdateElement(element.copy(rotation = it))
                            },
                            onValueChangeFinished = { isEditingBySlider = false },
                            enabled = !element.isLocked
                        )

                        // 2e. Tilt (الإمالة)
                        LeafAdjustmentSliderItem(
                            label = "الإمالة",
                            value = element.tilt,
                            valueRange = -60f..60f,
                            onValueChange = {
                                isEditingBySlider = true
                                onUpdateElement(element.copy(tilt = it))
                            },
                            onValueChangeFinished = { isEditingBySlider = false },
                            enabled = !element.isLocked
                        )
                    }
                }

                // 3. LEAF SHAPE PRESETS (شكل الورقة)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "شكل الورقة",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val shapeLabels = listOf(
                            "طبيعية", "بيضاوية", "طويلة", "عريضة",
                            "مدببة", "دائرية", "قلبية", "مسننة"
                        )

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            shapeLabels.forEachIndexed { index, label ->
                                val isSelected = element.leafShapePreset == index
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) GoldPrimary else TealMedium.copy(alpha = 0.4f))
                                        .clickable {
                                            onUpdateElement(element.copy(leafShapePreset = index))
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) TealDeep else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. LEAF COLORS SECTION (ألوان الورقة)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "ألوان الورقة",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val colorsList = listOf(
                            Color(0xFF81C784) to "أخضر فاتح",
                            Color(0xFF4CAF50) to "أخضر طبيعي",
                            Color(0xFF1B5E20) to "أخضر داكن",
                            Color(0xFFFDD835) to "أصفر",
                            Color(0xFFFB8C00) to "برتقالي",
                            Color(0xFFD84315) to "أحمر خريفي",
                            Color(0xFF8D6E63) to "بني"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            colorsList.forEachIndexed { index, (color, label) ->
                                val isSelected = element.leafColorPreset == index && element.customLeafColor == null
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) GoldLight else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onUpdateElement(element.copy(leafColorPreset = index, customLeafColor = null))
                                        }
                                )
                            }

                            // Color Picker Button
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .then(
                                        if (element.customLeafColor != null) {
                                            Modifier.background(Color(element.customLeafColor))
                                        } else {
                                            Modifier.background(androidx.compose.ui.graphics.Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Red)))
                                        }
                                    )
                                    .border(
                                        width = if (element.customLeafColor != null) 2.dp else 0.dp,
                                        color = if (element.customLeafColor != null) GoldLight else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { showColorPicker = true }
                            )
                        }

                        if (element.customLeafColor != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "لون مخصص نشط",
                                color = GoldPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 5. EFFECTS SECTION (التأثيرات)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = TealMedium.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "التأثيرات",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )

                        // 5a. Vein Clarity (زيادة وضوح عروق الورقة)
                        LeafAdjustmentSliderItem(
                            label = "وضوح عروق الورقة",
                            value = element.leafVeinClarity,
                            valueRange = 0f..1f,
                            onValueChange = {
                                onUpdateElement(element.copy(leafVeinClarity = it))
                            },
                            onValueChangeFinished = {},
                            enabled = !element.isLocked
                        )

                        // 5b. Edge Smoothing (تنعيم الحواف)
                        LeafAdjustmentSliderItem(
                            label = "تنعيم الحواف",
                            value = element.leafEdgeSmoothing,
                            valueRange = 0f..1f,
                            onValueChange = {
                                onUpdateElement(element.copy(leafEdgeSmoothing = it))
                            },
                            onValueChangeFinished = {},
                            enabled = !element.isLocked
                        )

                        // 5c. Opacity (شفافية)
                        LeafAdjustmentSliderItem(
                            label = "الشفافية",
                            value = element.leafOpacity,
                            valueRange = 0.1f..1f,
                            onValueChange = {
                                onUpdateElement(element.copy(leafOpacity = it))
                            },
                            onValueChangeFinished = {},
                            enabled = !element.isLocked
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // 5d. Boolean effects chips
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val effects = listOf(
                                "ظل خفيف" to element.leafShadow,
                                "لمعان بسيط" to element.leafShine,
                                "تأثير ثلاثي الأبعاد" to element.leaf3d
                            )
                            effects.forEach { (label, active) ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) GoldPrimary else TealMedium.copy(alpha = 0.4f))
                                        .clickable {
                                            when (label) {
                                                "ظل خفيف" -> onUpdateElement(element.copy(leafShadow = !element.leafShadow))
                                                "لمعان بسيط" -> onUpdateElement(element.copy(leafShine = !element.leafShine))
                                                "تأثير ثلاثي الأبعاد" -> onUpdateElement(element.copy(leaf3d = !element.leaf3d))
                                            }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (active) TealDeep else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = GoldPrimary.copy(alpha = 0.15f))

                // 6. ACTION CONTROLS & UTILITIES
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Copy & Paste Settings Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onCopySettings(element) },
                            colors = ButtonDefaults.buttonColors(containerColor = TealMedium.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = GoldLight, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ الخصائص", color = GoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onPasteSettings(element.id) },
                            enabled = hasCopiedSettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasCopiedSettings) TealMedium.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.05f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, tint = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.2f), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("لصق الخصائص", color = if (hasCopiedSettings) GoldLight else Color.White.copy(alpha = 0.25f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Lock & Show/Hide Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Lock state
                        Button(
                            onClick = { onUpdateElement(element.copy(isLocked = !element.isLocked)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (element.isLocked) Color(0xFFC0392B).copy(alpha = 0.25f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (element.isLocked) Color.Red else GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isLocked) "إلغاء قفل الورقة" else "قفل الورقة",
                                color = if (element.isLocked) Color.Red else GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Visibility state
                        Button(
                            onClick = { onUpdateElement(element.copy(isVisible = !element.isVisible)) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!element.isVisible) Color(0xFF7F8C8D).copy(alpha = 0.2f) else TealMedium.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (element.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (element.isVisible) "إخفاء الورقة" else "إظهار الورقة",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Reset Default Values button
                    Button(
                        onClick = {
                            onUpdateElement(
                                element.copy(
                                    scale = 1.0f,
                                    rotation = 0f,
                                    length = 1.0f,
                                    thickness = 1.0f,
                                    tilt = 0f,
                                    isLocked = false,
                                    isVisible = true,
                                    leafName = "",
                                    leafShapePreset = 0,
                                    leafColorPreset = 0,
                                    customLeafColor = null,
                                    leafVeinClarity = 0.5f,
                                    leafEdgeSmoothing = 0.0f,
                                    leafShadow = false,
                                    leafShine = false,
                                    leaf3d = false,
                                    leafOpacity = 1.0f
                                )
                            )
                            leafNameText = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = GoldLight, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إعادة القيم الافتراضية", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Delete Leaf button
            Button(
                onClick = { showDeleteConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC0392B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("حذف الورقة بالكامل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }

    // Beautiful Color Picker Dialog
    if (showColorPicker) {
        val pickerColors = listOf(
            Color(0xFFE8F5E9), Color(0xFFC8E6C9), Color(0xFFA5D6A7), Color(0xFF81C784),
            Color(0xFF66BB6A), Color(0xFF4CAF50), Color(0xFF43A047), Color(0xFF388E3C),
            Color(0xFF2E7D32), Color(0xFF1B5E20), Color(0xFFE0F2F1), Color(0xFFB2DFDB),
            Color(0xFF80CBC4), Color(0xFF4DB6AC), Color(0xFF26A69A), Color(0xFF009688),
            Color(0xFF00897B), Color(0xFF00796B), Color(0xFFFFFDE7), Color(0xFFFFF9C4),
            Color(0xFFFFF59D), Color(0xFFFFF176), Color(0xFFFFEE58), Color(0xFFFDD835),
            Color(0xFFFBC02D), Color(0xFFF57F17), Color(0xFFFFE0B2), Color(0xFFFFCC80),
            Color(0xFFFFB74D), Color(0xFFFF9800), Color(0xFFF57C00), Color(0xFFE65100),
            Color(0xFFFFCCBC), Color(0xFFFFAA91), Color(0xFFFF8A65), Color(0xFFFF7043),
            Color(0xFFF4511E), Color(0xFFD84315), Color(0xFFBF360C)
        )

        AlertDialog(
            onDismissRequest = { showColorPicker = false },
            title = {
                Text(
                    text = "اختر لوناً مخصصاً",
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )
            },
            text = {
                Column {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pickerColors.forEach { color ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (element.customLeafColor == color.toArgb().toLong()) 2.dp else 0.dp,
                                        color = if (element.customLeafColor == color.toArgb().toLong()) GoldLight else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onUpdateElement(element.copy(customLeafColor = color.toArgb().toLong()))
                                    }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showColorPicker = false }) {
                    Text("تم", color = GoldLight, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = TealDeep,
            tonalElevation = 6.dp
        )
    }
}

@Composable
private fun LeafAdjustmentSliderItem(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = if (enabled) 1.0f else 0.45f }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(String.format("%.2f", value), color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Slider(
            value = value,
            valueRange = valueRange,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = GoldPrimary,
                activeTrackColor = GoldPrimary,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                disabledThumbColor = Color.Gray,
                disabledActiveTrackColor = Color.Gray
            ),
            modifier = Modifier.height(30.dp)
        )
    }
}
