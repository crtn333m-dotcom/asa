package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.FamilyMember
import com.example.data.repository.FamilyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Canvas : Screen()
    object Welcome : Screen()
    object Dashboard : Screen()
}

class FamilyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FamilyRepository
    val allMembers: StateFlow<List<FamilyMember>>

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedMember = MutableStateFlow<FamilyMember?>(null)
    val selectedMember: StateFlow<FamilyMember?> = _selectedMember.asStateFlow()

    // Canvas designer states
    private val _canvasElements = MutableStateFlow<List<com.example.ui.screens.CanvasElement>>(emptyList())
    val canvasElements: StateFlow<List<com.example.ui.screens.CanvasElement>> = _canvasElements.asStateFlow()

    private val _activeElementId = MutableStateFlow<String?>(null)
    val activeElementId: StateFlow<String?> = _activeElementId.asStateFlow()

    private val _isPanelOpen = MutableStateFlow<Boolean>(false)
    val isPanelOpen: StateFlow<Boolean> = _isPanelOpen.asStateFlow()

    fun setActiveElementId(id: String?) {
        _activeElementId.value = id
    }

    fun setPanelOpen(open: Boolean) {
        _isPanelOpen.value = open
    }

    // Undo / Redo Stacks
    private val undoStack = java.util.Collections.synchronizedList(mutableListOf<List<com.example.ui.screens.CanvasElement>>())
    private val redoStack = java.util.Collections.synchronizedList(mutableListOf<List<com.example.ui.screens.CanvasElement>>())

    // Clipboard Support
    private var copiedTrunkSettings: com.example.ui.screens.CanvasElement? = null

    private fun saveToUndo() {
        // Deep copy list and names list
        val snapshot = _canvasElements.value.map { it.copy(names = it.names.toList()) }
        undoStack.add(snapshot)
        redoStack.clear()
        if (undoStack.size > 50) {
            undoStack.removeAt(0)
        }
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val previous = undoStack.removeAt(undoStack.size - 1)
            val current = _canvasElements.value.map { it.copy(names = it.names.toList()) }
            redoStack.add(current)
            _canvasElements.value = previous
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.size - 1)
            val current = _canvasElements.value.map { it.copy(names = it.names.toList()) }
            undoStack.add(current)
            _canvasElements.value = next
        }
    }

    fun copyTrunkSettings(element: com.example.ui.screens.CanvasElement) {
        copiedTrunkSettings = element.copy()
    }

    fun pasteTrunkSettings(targetId: String) {
        val settings = copiedTrunkSettings ?: return
        saveToUndo()
        _canvasElements.value = _canvasElements.value.map {
            if (it.id == targetId) {
                it.copy(
                    scale = settings.scale,
                    rotation = settings.rotation,
                    length = settings.length,
                    thickness = settings.thickness,
                    tilt = settings.tilt,
                    tipTaper = settings.tipTaper,
                    deform = settings.deform,
                    woodColorPreset = settings.woodColorPreset,
                    effectsPreset = settings.effectsPreset,
                    isVisible = settings.isVisible
                )
            } else it
        }
    }

    fun hasCopiedSettings(): Boolean = copiedTrunkSettings != null

    fun addCanvasElement(type: com.example.ui.screens.ElementType, x: Float, y: Float) {
        // Only allow one trunk
        if (type == com.example.ui.screens.ElementType.TRUNK && _canvasElements.value.any { it.type == com.example.ui.screens.ElementType.TRUNK }) {
            return
        }
        saveToUndo()
        val currentList = _canvasElements.value.toMutableList()
        val newElement = com.example.ui.screens.CanvasElement(type = type, x = x, y = y)
        currentList.add(newElement)
        _canvasElements.value = currentList
        _activeElementId.value = newElement.id
        _isPanelOpen.value = true
    }

    fun updateCanvasElement(updated: com.example.ui.screens.CanvasElement) {
        // We only save to undo if something actually changes
        val current = _canvasElements.value.find { it.id == updated.id }
        if (current != null && current != updated) {
            saveToUndo()
            _canvasElements.value = _canvasElements.value.map {
                if (it.id == updated.id) updated else it
            }
        }
    }

    fun deleteCanvasElement(id: String) {
        val element = _canvasElements.value.find { it.id == id }
        val parentId = element?.parentId

        saveToUndo()
        val toDelete = mutableSetOf<String>()
        getDescendantIds(id, _canvasElements.value, toDelete)
        toDelete.add(id)

        val currentList = _canvasElements.value.filter { it.id !in toDelete }.toMutableList()

        if (parentId != null) {
            redistributeChildren(parentId, currentList)
        }

        _canvasElements.value = currentList

        if (_activeElementId.value in toDelete) {
            _activeElementId.value = null
            _isPanelOpen.value = false
        }
    }

    private fun getDescendantIds(parentId: String, list: List<com.example.ui.screens.CanvasElement>, outSet: MutableSet<String>) {
        list.forEach { item ->
            if (item.parentId == parentId) {
                if (outSet.add(item.id)) {
                    getDescendantIds(item.id, list, outSet)
                }
            }
        }
    }

    private fun redistributeChildren(parentId: String, currentList: MutableList<com.example.ui.screens.CanvasElement>) {
        val parent = currentList.find { it.id == parentId } ?: return
        val children = currentList.filter { it.parentId == parentId }
        if (children.isEmpty()) return

        val n = children.size
        if (n == 1) {
            val child = children[0]
            val idx = currentList.indexOfFirst { it.id == child.id }
            if (idx != -1) {
                currentList[idx] = child.copy(rotation = (parent.rotation + 25f) % 360f)
            }
        } else {
            // Spread evenly between parent.rotation - 55f and parent.rotation + 55f
            val startAngle = parent.rotation - 55f
            val endAngle = parent.rotation + 55f
            val step = 110f / (n - 1)
            children.forEachIndexed { i, child ->
                val idx = currentList.indexOfFirst { it.id == child.id }
                if (idx != -1) {
                    currentList[idx] = child.copy(rotation = (startAngle + i * step) % 360f)
                }
            }
        }
    }

    fun addChildElement(parentId: String, type: com.example.ui.screens.ElementType) {
        val parent = _canvasElements.value.find { it.id == parentId } ?: return
        saveToUndo()
        val currentList = _canvasElements.value.toMutableList()
        val child = com.example.ui.screens.CanvasElement(
            type = type,
            x = parent.x,
            y = parent.y,
            scale = if (type == com.example.ui.screens.ElementType.LEAF) 0.8f else (parent.scale * 0.9f).coerceIn(0.4f, 3.0f),
            rotation = parent.rotation,
            parentId = parentId
        )
        currentList.add(child)
        redistributeChildren(parentId, currentList)
        _canvasElements.value = currentList
        _activeElementId.value = child.id
        _isPanelOpen.value = true
    }

    fun addChildBranch(parentId: String) {
        addChildElement(parentId, com.example.ui.screens.ElementType.BRANCH)
    }

    fun clearCanvas() {
        saveToUndo()
        _canvasElements.value = emptyList()
        _activeElementId.value = null
        _isPanelOpen.value = false
    }

    fun loadImportedTree() {
        saveToUndo()
        _canvasElements.value = listOf(
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.TRUNK,
                x = 0.50f,
                y = 0.70f,
                scale = 1.3f
            ),
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.BRANCH,
                x = 0.36f,
                y = 0.48f,
                scale = 0.95f,
                rotation = 35f
            ),
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.BRANCH,
                x = 0.64f,
                y = 0.52f,
                scale = 0.95f,
                rotation = -40f
            ),
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.LEAF,
                x = 0.22f,
                y = 0.33f,
                scale = 0.9f,
                rotation = 15f
            ),
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.LEAF,
                x = 0.78f,
                y = 0.36f,
                scale = 0.9f,
                rotation = -15f
            ),
            com.example.ui.screens.CanvasElement(
                type = com.example.ui.screens.ElementType.LEAF,
                x = 0.50f,
                y = 0.25f,
                scale = 1.0f,
                rotation = 0f
            )
        )
    }

    init {
        val familyDao = AppDatabase.getDatabase(application).familyDao()
        repository = FamilyRepository(familyDao)

        allMembers = repository.allMembers
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        // Pre-populate if database is empty on first startup
        viewModelScope.launch {
            try {
                val list = repository.allMembers.first()
                if (list.isEmpty()) {
                    initializeDefaultTree()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectMember(member: FamilyMember?) {
        _selectedMember.value = member
    }

    private suspend fun initializeDefaultTree() {
        val defaultMembers = listOf(
            FamilyMember(id = 1, name = "سليمان", relation = "الجد", gender = "Male", generation = 0, relativeX = 0.35f, relativeY = 0.20f),
            FamilyMember(id = 2, name = "فاطمة", relation = "الجدة", gender = "Female", generation = 0, relativeX = 0.65f, relativeY = 0.20f),
            
            FamilyMember(id = 3, name = "عبد الله", relation = "الأب", gender = "Male", generation = 1, relativeX = 0.30f, relativeY = 0.45f, parentId = 1),
            FamilyMember(id = 4, name = "مريم", relation = "الأم", gender = "Female", generation = 1, relativeX = 0.50f, relativeY = 0.45f, parentId = 2),
            FamilyMember(id = 5, name = "أحمد", relation = "العم", gender = "Male", generation = 1, relativeX = 0.15f, relativeY = 0.42f, parentId = 1),
            FamilyMember(id = 6, name = "سارة", relation = "العمة", gender = "Female", generation = 1, relativeX = 0.70f, relativeY = 0.42f, parentId = 2),
            
            FamilyMember(id = 7, name = "يوسف (أنا)", relation = "أنا", gender = "Male", generation = 2, relativeX = 0.30f, relativeY = 0.68f, parentId = 3),
            FamilyMember(id = 8, name = "خالد", relation = "الأخ", gender = "Male", generation = 2, relativeX = 0.15f, relativeY = 0.66f, parentId = 3),
            FamilyMember(id = 9, name = "منى", relation = "الأخت", gender = "Female", generation = 2, relativeX = 0.50f, relativeY = 0.66f, parentId = 3),
            
            FamilyMember(id = 10, name = "عمر", relation = "الابن", gender = "Male", generation = 3, relativeX = 0.35f, relativeY = 0.88f, parentId = 7),
            FamilyMember(id = 11, name = "ليلى", relation = "الابنة", gender = "Female", generation = 3, relativeX = 0.55f, relativeY = 0.88f, parentId = 7)
        )
        repository.insertAll(defaultMembers)
    }

    fun resetToDefaultTree() {
        viewModelScope.launch {
            repository.clearAll()
            initializeDefaultTree()
            _selectedMember.value = null
        }
    }

    fun addFamilyMember(
        name: String,
        relation: String,
        gender: String,
        parentId: Int?
    ) {
        viewModelScope.launch {
            val parent = parentId?.let { id -> allMembers.value.find { it.id == id } }
            
            // Determine generation tier based on parent or relationship
            val generation = when (relation) {
                "الجد", "الجدة" -> 0
                "الأب", "الأم", "العم", "العمة", "الخال", "الخالة" -> 1
                "أنا", "الأخ", "الأخت", "الزوج", "الزوجة" -> 2
                "الابن", "الابنة" -> 3
                else -> parent?.let { it.generation + 1 }?.coerceIn(0, 3) ?: 2
            }

            // Intelligent visual coordinate calculation based on parent node
            val base_x = parent?.relativeX ?: 0.5f
            val base_y = parent?.relativeY ?: 0.5f

            // Add staggered visual offsets depending on relationship
            val offset_x = when {
                relation.contains("الابن") || relation.contains("الابنة") -> {
                    val siblingsCount = allMembers.value.count { it.parentId == parentId }
                    if (siblingsCount % 2 == 0) 0.10f else -0.10f
                }
                relation.contains("أخ") || relation.contains("أخت") -> {
                    val siblingsCount = allMembers.value.count { it.parentId == parentId }
                    if (siblingsCount % 2 == 0) -0.15f else 0.15f
                }
                else -> (Math.random().toFloat() * 0.2f - 0.1f)
            }

            val offset_y = when (generation) {
                0 -> -0.2f
                1 -> -0.1f
                2 -> 0.1f
                3 -> 0.2f
                else -> 0.15f
            }

            val relativeX = (base_x + offset_x).coerceIn(0.08f, 0.92f)
            val relativeY = (base_y + offset_y).coerceIn(0.12f, 0.90f)

            val newMember = FamilyMember(
                name = name,
                relation = relation,
                gender = gender,
                generation = generation,
                relativeX = relativeX,
                relativeY = relativeY,
                parentId = parentId
            )
            repository.insert(newMember)
        }
    }

    fun updateFamilyMember(member: FamilyMember) {
        viewModelScope.launch {
            repository.update(member)
            if (_selectedMember.value?.id == member.id) {
                _selectedMember.value = member
            }
        }
    }

    fun deleteFamilyMember(member: FamilyMember) {
        viewModelScope.launch {
            repository.delete(member)
            _selectedMember.value = null
        }
    }
}
