package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.FamilyMember
import com.example.ui.FamilyViewModel
import com.example.ui.Screen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.CanvasScreen
import com.example.ui.widgets.AmbientGlowingSpecks
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

// Visual Particle Data Class for the click explosion
data class GlowParticle(
    val id: Int,
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    var alpha: Float,
    val size: Float,
    val color: Color
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    FamilyTreeApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun FamilyTreeApp(
    modifier: Modifier = Modifier,
    viewModel: FamilyViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val members by viewModel.allMembers.collectAsStateWithLifecycle()
    val selectedMember by viewModel.selectedMember.collectAsStateWithLifecycle()
    val canvasElements by viewModel.canvasElements.collectAsStateWithLifecycle()
    val activeElementId by viewModel.activeElementId.collectAsStateWithLifecycle()
    val isPanelOpen by viewModel.isPanelOpen.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .background(
                Brush.verticalGradient(
                    colors = listOf(TealDeep, TealMedium, TealDeep)
                )
            )
    ) {
        // Serene animated ambient specks/dust in the background
        AmbientGlowingSpecks()

        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn(animationSpec = tween(500)) togetherWith
                fadeOut(animationSpec = tween(500))
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                is Screen.Home -> {
                    HomeScreen(
                        onCreateProject = {
                            viewModel.clearCanvas()
                            viewModel.navigateTo(Screen.Canvas)
                        },
                        onImportProject = {
                            viewModel.loadImportedTree()
                            viewModel.navigateTo(Screen.Canvas)
                        }
                    )
                }
                is Screen.Canvas -> {
                    CanvasScreen(
                        elements = canvasElements,
                        activeElementId = activeElementId,
                        onActiveElementChange = { viewModel.setActiveElementId(it) },
                        isPanelOpen = isPanelOpen,
                        onPanelOpenChange = { viewModel.setPanelOpen(it) },
                        onAddElement = { type, x, y ->
                            viewModel.addCanvasElement(type, x, y)
                        },
                        onUpdateElement = { element ->
                            viewModel.updateCanvasElement(element)
                        },
                        onDeleteElement = { id ->
                            viewModel.deleteCanvasElement(id)
                        },
                        onClearCanvas = {
                            viewModel.clearCanvas()
                        },
                        onBack = {
                            viewModel.navigateTo(Screen.Home)
                        },
                        onUndo = { viewModel.undo() },
                        onRedo = { viewModel.redo() },
                        canUndo = viewModel.canUndo(),
                        canRedo = viewModel.canRedo(),
                        onCopySettings = { viewModel.copyTrunkSettings(it) },
                        onPasteSettings = { viewModel.pasteTrunkSettings(it) },
                        hasCopiedSettings = viewModel.hasCopiedSettings(),
                        onAddChildElement = { parentId, type -> viewModel.addChildElement(parentId, type) }
                    )
                }
                is Screen.Welcome -> {
                    WelcomeScreen(
                        members = members,
                        onEnterClick = {
                            viewModel.navigateTo(Screen.Dashboard)
                        }
                    )
                }
                is Screen.Dashboard -> {
                    DashboardScreen(
                        members = members,
                        selectedMember = selectedMember,
                        onMemberClick = { viewModel.selectMember(it) },
                        onAddMember = { name, relation, gender, parentId ->
                            viewModel.addFamilyMember(name, relation, gender, parentId)
                        },
                        onUpdateMember = { viewModel.updateFamilyMember(it) },
                        onDeleteMember = { viewModel.deleteFamilyMember(it) },
                        onResetTree = { viewModel.resetToDefaultTree() },
                        onDismissDetails = { viewModel.selectMember(null) }
                    )
                }
            }
        }
    }
}
/**
 * Welcome / Landing screen containing the Family Tree visual preview and the bouncy Enter button.
 */
@Composable
fun WelcomeScreen(
    members: List<FamilyMember>,
    onEnterClick: () -> Unit
) {
    var particles by remember { mutableStateOf(emptyList<GlowParticle>()) }
    var particleIdCounter by remember { mutableStateOf(0) }
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    // Background thread updating particle coordinates for click blast
    LaunchedEffect(particles) {
        if (particles.isNotEmpty()) {
            delay(16) // ~60fps
            particles = particles.map { p ->
                p.copy(
                    x = p.x + p.vx,
                    y = p.y + p.vy,
                    vy = p.vy + 0.15f, // slight gravity
                    alpha = (p.alpha - 0.04f).coerceAtLeast(0f)
                )
            }.filter { it.alpha > 0f }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Visual Title Block at the top
        Text(
            text = "شجرة العائلة",
            fontSize = 38.sp,
            fontWeight = FontWeight.Bold,
            color = GoldPrimary,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.headlineLarge.copy(
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.5f),
                    offset = Offset(2f, 4f),
                    blurRadius = 8f
                )
            )
        )

        Text(
            text = "صلة رحم وميثاق أجيال",
            fontSize = 15.sp,
            color = GoldLight.copy(alpha = 0.85f),
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )

        // The beautiful family tree illustration/preview
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                .background(TealDeep.copy(alpha = 0.4f)),
            contentAlignment = Alignment.Center
        ) {
            FamilyTreeCanvas(
                members = members,
                selectedMember = null,
                onMemberClick = {},
                isTablet = false,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Welcome text requested by user: "اهلا بكم في تطبيقي"
        Text(
            text = "أهلاً بكم في تطبيقي",
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Text(
            text = "سجل نسب عائلتك، وثّق أفرادها، وتصفح فروعها وأصولها بتصميم تفاعلي ساحر.",
            fontSize = 14.sp,
            color = CreamBackground.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 8.dp, bottom = 32.dp)
                .widthIn(max = 320.dp)
        )

        // The interactive button with advanced visual effects (Spring bounce + Particle Burst)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(width = 240.dp, height = 120.dp)
                .testTag("entry_button_container")
        ) {
            val interactionSource = remember { MutableInteractionSource() }
            val isPressed by interactionSource.collectIsPressedAsState()
            
            val scale by animateFloatAsState(
                targetValue = if (isPressed) 0.92f else 1.0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                ),
                label = "ButtonScale"
            )

            // Draw click blast particles over the button area
            Canvas(
                modifier = Modifier.fillMaxSize()
            ) {
                particles.forEach { p ->
                    drawCircle(
                        color = p.color.copy(alpha = p.alpha),
                        radius = p.size,
                        center = Offset(p.x, p.y)
                    )
                }
            }

            Button(
                onClick = {
                    // Trigger beautiful explosion of golden dust from center of the button!
                    val random = java.util.Random()
                    // Target coordinates relative to the 240x120 container
                    val px = with(density) { 120.dp.toPx() }
                    val py = with(density) { 60.dp.toPx() }
                    
                    val newParticles = List(35) {
                        val angle = random.nextDouble() * 2 * Math.PI
                        val speed = 3f + random.nextFloat() * 12f
                        GlowParticle(
                            id = particleIdCounter++,
                            x = px,
                            y = py,
                            vx = (cos(angle) * speed).toFloat(),
                            vy = (sin(angle) * speed).toFloat() - 3f, // blast upwards slightly
                            alpha = 1.0f,
                            size = with(density) { (4 + random.nextInt(8)).dp.toPx() },
                            color = if (random.nextBoolean()) GoldLight else GoldPrimary
                        )
                    }
                    particles = particles + newParticles
                    
                    // Delay entry navigation to let the explosion burst show beautifully!
                    coroutineScope.launch {
                        delay(450)
                        onEnterClick()
                    }
                },
                interactionSource = interactionSource,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, GoldLight),
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .height(56.dp)
                    .width(200.dp)
                    .align(Alignment.Center)
                    .testTag("login_button")
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "دخول التطبيق",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealDeep
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowBack, // Standard arrow, reversed in RTL
                        contentDescription = "دخول",
                        tint = TealDeep,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

/**
 * Interactive Dashboard: Shows tree visualization on top (or left) and family directory on bottom (or right).
 */
@Composable
fun DashboardScreen(
    members: List<FamilyMember>,
    selectedMember: FamilyMember?,
    onMemberClick: (FamilyMember) -> Unit,
    onAddMember: (String, String, String, Int?) -> Unit,
    onUpdateMember: (FamilyMember) -> Unit,
    onDeleteMember: (FamilyMember) -> Unit,
    onResetTree: () -> Unit,
    onDismissDetails: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600
    
    var showAddDialog by remember { mutableStateOf(false) }

    if (isTablet) {
        // LANDSCAPE / TABLET LAYOUT: Split-Screen Side-by-Side (60% visual tree map, 40% management dashboard)
        Row(
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .weight(0.6f)
                    .fillMaxHeight()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .border(2.dp, GoldPrimary.copy(alpha = 0.3f), RoundedCornerShape(28.dp))
                    .background(TealDeep.copy(alpha = 0.3f))
            ) {
                FamilyTreeCanvas(
                    members = members,
                    selectedMember = selectedMember,
                    onMemberClick = onMemberClick,
                    isTablet = true,
                    modifier = Modifier.fillMaxSize()
                )

                // Quick Floating Reset Tree button
                IconButton(
                    onClick = onResetTree,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .background(TealMedium, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "إعادة ضبط الشجرة",
                        tint = GoldLight
                    )
                }
            }

            // Right Pane: Directory list and Member detail controls
            Column(
                modifier = Modifier
                    .weight(0.4f)
                    .fillMaxHeight()
                    .background(TealDeep.copy(alpha = 0.85f))
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "لوحة التحكم والعائلة",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة قريب", tint = TealDeep)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إضافة فرد عائلة جديد", fontWeight = FontWeight.Bold, color = TealDeep)
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (selectedMember != null) {
                    MemberDetailCard(
                        member = selectedMember,
                        allMembers = members,
                        onUpdate = onUpdateMember,
                        onDelete = onDeleteMember,
                        onClose = onDismissDetails
                    )
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TealMedium.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = GoldPrimary.copy(alpha = 0.6f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "اضغط على أي فرد في الشجرة لعرض تفاصيله أو تعديلها أو ربط فرع جديد به.",
                                fontSize = 14.sp,
                                color = CreamBackground.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                FamilyDirectoryList(members = members, onMemberClick = onMemberClick)
            }
        }
    } else {
        // PORTRAIT / PHONE LAYOUT: Stacked Layout (Visual map on top, quick listing on bottom)
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Interactive visual tree canvas
            Box(
                modifier = Modifier
                    .weight(0.55f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.5.dp, GoldPrimary.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .background(TealDeep.copy(alpha = 0.25f))
            ) {
                FamilyTreeCanvas(
                    members = members,
                    selectedMember = selectedMember,
                    onMemberClick = onMemberClick,
                    isTablet = false,
                    modifier = Modifier.fillMaxSize()
                )

                // Quick buttons inside visual header
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onResetTree,
                        modifier = Modifier
                            .size(36.dp)
                            .background(TealMedium.copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "إعادة ضبط الشجرة",
                            tint = GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Lower Section: Scrollable Directory List & Actions
            Column(
                modifier = Modifier
                    .weight(0.45f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(TealMedium.copy(alpha = 0.4f))
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "شجرتنا العائلية",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )

                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = TealDeep, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة", fontWeight = FontWeight.Bold, color = TealDeep, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier.weight(1f)
                ) {
                    FamilyDirectoryList(
                        members = members,
                        onMemberClick = {
                            onMemberClick(it)
                        }
                    )
                }
            }
        }

        // Slide up modal-like sheet for mobile detail edits
        if (selectedMember != null) {
            AlertDialog(
                onDismissRequest = onDismissDetails,
                confirmButton = {},
                dismissButton = {},
                title = null,
                text = {
                    MemberDetailCard(
                        member = selectedMember,
                        allMembers = members,
                        onUpdate = onUpdateMember,
                        onDelete = onDeleteMember,
                        onClose = onDismissDetails
                    )
                },
                containerColor = TealMedium,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(8.dp)
            )
        }
    }

    // Comprehensive Member Add Dialog (Renders on overlay)
    if (showAddDialog) {
        AddMemberDialog(
            allMembers = members,
            onDismiss = { showAddDialog = false },
            onSave = { name, relation, gender, parentId ->
                onAddMember(name, relation, gender, parentId)
                showAddDialog = false
            }
        )
    }
}

/**
 * Beautiful Hybrid Family Tree Canvas.
 * Draws connections on Canvas and overlays interactive Jetpack Compose composables at calculated coordinates.
 */
@Composable
fun FamilyTreeCanvas(
    members: List<FamilyMember>,
    selectedMember: FamilyMember?,
    onMemberClick: (FamilyMember) -> Unit,
    isTablet: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        val nodeSize = if (isTablet) 72.dp else 56.dp

        // 1. Draw organic connecting tree branches underneath
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (width > 0 && height > 0) {
                // Organic background trunk drawing
                val trunkBottom = Offset(width * 0.5f, height * 0.98f)
                val trunkFork = Offset(width * 0.5f, height * 0.70f)
                
                val trunkPath = Path().apply {
                    moveTo(trunkBottom.x, trunkBottom.y)
                    quadraticBezierTo(
                        width * 0.5f, height * 0.85f,
                        trunkFork.x, trunkFork.y
                    )
                }

                // Soft background shadow glow for organic feel
                drawPath(
                    path = trunkPath,
                    color = GoldDark.copy(alpha = 0.25f),
                    style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                )

                // Main trunk paint
                drawPath(
                    path = trunkPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(GoldDark, GoldPrimary)
                    ),
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw curve connection lines from children nodes to parent nodes
                members.forEach { member ->
                    member.parentId?.let { pId ->
                        val parent = members.find { it.id == pId }
                        if (parent != null) {
                            val startX = parent.relativeX * width
                            val startY = parent.relativeY * height
                            val endX = member.relativeX * width
                            val endY = member.relativeY * height

                            val branchPath = Path().apply {
                                moveTo(startX, startY)
                                // Standard curve logic to represent realistic, sweeping branches
                                val ctrlX = (startX + endX) / 2f
                                val ctrlY = (startY + endY) / 2f - 30.dp.toPx()
                                quadraticBezierTo(ctrlX, ctrlY, endX, endY)
                            }

                            // Soft branch glow
                            drawPath(
                                path = branchPath,
                                color = GoldLight.copy(alpha = 0.2f),
                                style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                            )

                            // Clean elegant branch line
                            drawPath(
                                path = branchPath,
                                brush = Brush.linearGradient(
                                    colors = listOf(GoldPrimary, GoldLight)
                                ),
                                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            )

                            // Decorative organic green leaves blooming along branches
                            val leafX = (startX + endX) / 2f
                            val leafY = (startY + endY) / 2f - 15.dp.toPx()
                            drawCircle(
                                color = GreenLeaf.copy(alpha = 0.8f),
                                radius = 5.dp.toPx(),
                                center = Offset(leafX, leafY)
                            )
                            drawCircle(
                                color = GreenLeafLight.copy(alpha = 0.8f),
                                radius = 3.dp.toPx(),
                                center = Offset(leafX - 6.dp.toPx(), leafY - 4.dp.toPx())
                            )
                        }
                    }
                }
            }
        }

        // 2. Overlay clickable, beautiful family members at relative coordinates
        members.forEach { member ->
            val relX = member.relativeX
            val relY = member.relativeY

            // Calculate exact offset positions
            val xOffset = (relX * maxWidth.value).dp - (nodeSize / 2)
            val yOffset = (relY * maxHeight.value).dp - (nodeSize / 2)

            Box(
                modifier = Modifier
                    .offset(x = xOffset, y = yOffset)
                    .size(nodeSize)
            ) {
                FamilyNodeComponent(
                    member = member,
                    isSelected = selectedMember?.id == member.id,
                    onClick = { onMemberClick(member) }
                )
            }
        }
    }
}

/**
 * Individual Node design displaying gender-coded decorative rings and the person's name label.
 */
@Composable
fun FamilyNodeComponent(
    member: FamilyMember,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val scaleAnim by animateFloatAsState(
        targetValue = if (isSelected) 1.15f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "SelectedNodeScale"
    )

    val ringColor = if (member.gender == "Male") TealLight else GoldPrimary
    val avatarBg = if (member.gender == "Male") TealMedium else TealDeep

    Column(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = scaleAnim
                scaleY = scaleAnim
            }
            .clickable(
                onClick = onClick,
                indication = null, // Custom visual feedback via scale animations
                interactionSource = remember { MutableInteractionSource() }
            )
            .testTag("node_${member.id}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Round Golden Frame containing silhouette
        Box(
            modifier = Modifier
                .weight(1f)
                .aspectRatio(1f)
                .clip(CircleShape)
                .background(avatarBg)
                .border(
                    BorderStroke(
                        width = if (isSelected) 2.5.dp else 1.5.dp,
                        brush = Brush.radialGradient(
                            colors = if (isSelected) listOf(GoldLight, GoldPrimary, GoldDark) else listOf(ringColor, ringColor.copy(alpha = 0.6f))
                        )
                    ),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            // Silhouette Avatar representation
            Icon(
                imageVector = if (member.gender == "Male") Icons.Default.Person else Icons.Default.Face,
                contentDescription = null,
                tint = if (member.gender == "Male") TealLight.copy(alpha = 0.9f) else GoldLight.copy(alpha = 0.9f),
                modifier = Modifier.fillMaxSize(0.55f)
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Glassmorphic Mini label card overlapping slightly
        Card(
            colors = CardDefaults.cardColors(
                containerColor = TealDeep.copy(alpha = 0.9f)
            ),
            shape = RoundedCornerShape(4.dp),
            border = BorderStroke(0.5.dp, GoldPrimary.copy(alpha = 0.4f)),
            modifier = Modifier.wrapContentSize()
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = member.name,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = member.relation,
                    color = GoldLight,
                    fontSize = 7.sp,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Clean Directory/Index of all registered family members.
 */
@Composable
fun FamilyDirectoryList(
    members: List<FamilyMember>,
    onMemberClick: (FamilyMember) -> Unit
) {
    if (members.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("لا يوجد أفراد مسجلين بعد.", color = Color.LightGray, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(members) { member ->
                val itemColor = if (member.gender == "Male") TealLight else GoldPrimary

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(TealDeep.copy(alpha = 0.5f))
                        .clickable { onMemberClick(member) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(itemColor.copy(alpha = 0.2f))
                                .border(1.dp, itemColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (member.gender == "Male") Icons.Default.Person else Icons.Default.Face,
                                contentDescription = null,
                                tint = itemColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = member.name,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = member.relation,
                                color = GoldLight,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "استعراض",
                        tint = GoldLight.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Interactive card showing details of a selected member with delete and update controls.
 */
@Composable
fun MemberDetailCard(
    member: FamilyMember,
    allMembers: List<FamilyMember>,
    onUpdate: (FamilyMember) -> Unit,
    onDelete: (FamilyMember) -> Unit,
    onClose: () -> Unit
) {
    var isEditMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(member.name) }
    var notes by remember { mutableStateOf(member.notes) }

    Card(
        colors = CardDefaults.cardColors(containerColor = TealDeep),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, GoldPrimary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEditMode) "تعديل البيانات" else "تفاصيل الفرد",
                    color = GoldPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.LightGray)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (isEditMode) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم", color = GoldLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات / نبذة", color = GoldLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onUpdate(member.copy(name = name, notes = notes))
                            isEditMode = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حفظ", color = TealDeep, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { isEditMode = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = Color.White)
                    }
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.2f))
                            .border(1.5.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (member.gender == "Male") Icons.Default.Person else Icons.Default.Face,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = member.name,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = member.relation,
                            color = GoldLight,
                            fontSize = 14.sp
                        )
                    }
                }

                if (member.notes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("نبذة وملاحظات:", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(member.notes, color = Color.White, fontSize = 14.sp)
                }

                // Parent description if exists
                val parent = allMembers.find { it.id == member.parentId }
                if (parent != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "فرع متصل بـ: ${parent.name} (${parent.relation})",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { isEditMode = true },
                        modifier = Modifier
                            .weight(1f)
                            .background(TealMedium, RoundedCornerShape(10.dp))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = GoldLight)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تعديل", color = GoldLight, fontSize = 13.sp)
                        }
                    }

                    IconButton(
                        onClick = { onDelete(member) },
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF8B2635), RoundedCornerShape(10.dp))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Beautiful Overlay dialog to append details of a new family connection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMemberDialog(
    allMembers: List<FamilyMember>,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedRelation by remember { mutableStateOf("الابن") }
    var selectedGender by remember { mutableStateOf("Male") }
    var selectedParentId by remember { mutableStateOf<Int?>(null) }
    var expandedRelation by remember { mutableStateOf(false) }
    var expandedParent by remember { mutableStateOf(false) }

    val relationsList = listOf(
        "الابن", "الابنة", "الأخ", "الأخت", "الأب", "الأم", "الجد", "الجدة", "العم", "العمة", "الخال", "الخالة"
    )

    // Synchronize gender automatically depending on relationship selection
    LaunchedEffect(selectedRelation) {
        selectedGender = when (selectedRelation) {
            "الابنة", "الأخت", "الأم", "الجدة", "العمة", "الخالة" -> "Female"
            else -> "Male"
        }
        
        // Auto-select parent if empty and we have members
        if (selectedParentId == null && allMembers.isNotEmpty()) {
            // Default parent can be Me ("أنا") or first parent
            val me = allMembers.find { it.relation == "أنا" }
            selectedParentId = me?.id ?: allMembers.firstOrNull()?.id
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "إضافة قريب جديد",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم الكريم", color = GoldLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Relation Selector
                Column {
                    Text("صلة القرابة", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { expandedRelation = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TealDeep),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedRelation, color = Color.White)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldLight)
                            }
                        }

                        DropdownMenu(
                            expanded = expandedRelation,
                            onDismissRequest = { expandedRelation = false },
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .background(TealMedium)
                        ) {
                            relationsList.forEach { relation ->
                                DropdownMenuItem(
                                    text = { Text(relation, color = Color.White) },
                                    onClick = {
                                        selectedRelation = relation
                                        expandedRelation = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Gender Toggle
                Column {
                    Text("الجنس", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { selectedGender = "Male" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedGender == "Male") TealLight else Color.DarkGray
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ذكر", color = Color.White)
                        }

                        Button(
                            onClick = { selectedGender = "Female" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedGender == "Female") GoldPrimary else Color.DarkGray
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("أنثى", color = TealDeep)
                        }
                    }
                }

                // Parent Selector (Except for patriarchs like الجد/الجدة which don't need parent)
                if (selectedRelation != "الجد" && selectedRelation != "الجدة" && allMembers.isNotEmpty()) {
                    Column {
                        Text("الارتباط (متصل بـ)", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            val activeParent = allMembers.find { it.id == selectedParentId }
                            Button(
                                onClick = { expandedParent = true },
                                colors = ButtonDefaults.buttonColors(containerColor = TealDeep),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = activeParent?.let { "${it.name} (${it.relation})" } ?: "اختر فرد العائلة",
                                        color = Color.White
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldLight)
                                }
                            }

                            DropdownMenu(
                                expanded = expandedParent,
                                onDismissRequest = { expandedParent = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.7f)
                                    .background(TealMedium)
                            ) {
                                allMembers.forEach { m ->
                                    DropdownMenuItem(
                                        text = { Text("${m.name} (${m.relation})", color = Color.White) },
                                        onClick = {
                                            selectedParentId = m.id
                                            expandedParent = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotEmpty()) {
                        onSave(name, selectedRelation, selectedGender, selectedParentId)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                enabled = name.isNotEmpty()
            ) {
                Text("إضافة", color = TealDeep, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
            ) {
                Text("إلغاء", color = Color.White)
            }
        },
        containerColor = TealMedium,
        shape = RoundedCornerShape(20.dp)
    )
}
